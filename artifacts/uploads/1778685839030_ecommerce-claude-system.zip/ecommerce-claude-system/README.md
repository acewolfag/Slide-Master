# 🛒 E-Commerce Claude System

Bộ tài liệu và skill hoàn chỉnh giúp **Claude Code** xây dựng website bán hàng từ đầu đến hoàn thiện, được tối ưu cho thị trường Việt Nam.

## 📦 Bộ này gồm gì?

```
ecommerce-claude-system/
├── CLAUDE.md                    # 🎯 File config root - Claude đọc đầu tiên
├── .env.example                 # Template biến môi trường
├── README.md                    # File này
├── .claude/
│   ├── skills/                  # 10 skills chuyên môn
│   │   ├── ecommerce-architecture/SKILL.md
│   │   ├── ui-design/SKILL.md
│   │   ├── database-schema/SKILL.md
│   │   ├── api-design/SKILL.md
│   │   ├── payment-vn/SKILL.md       # VNPay, MoMo, ZaloPay
│   │   ├── seo-optimization/SKILL.md
│   │   ├── security/SKILL.md
│   │   ├── testing/SKILL.md
│   │   ├── deployment/SKILL.md
│   │   └── git-workflow/SKILL.md
│   └── commands/                # Slash commands tùy biến (tùy chọn)
└── docs/                        # Docs bổ sung (tùy chọn)
```

## 🚀 Cách sử dụng

### Bước 1: Copy bộ này vào dự án của bạn

```bash
# Trong thư mục dự án Next.js của bạn
cp -r ecommerce-claude-system/.claude ./
cp ecommerce-claude-system/CLAUDE.md ./
cp ecommerce-claude-system/.env.example ./
```

### Bước 2: Chỉnh sửa CLAUDE.md cho phù hợp dự án

Mở `CLAUDE.md` và cập nhật:
- Tên dự án, domain, mô tả
- Stack thực tế nếu khác (mặc định: Next.js 14 + TypeScript + Prisma + PostgreSQL)
- Folder structure nếu khác

### Bước 3: Mở Claude Code trong dự án

```bash
cd your-project
claude
```

Claude Code sẽ tự động:
- Đọc `CLAUDE.md` ở root
- Quét `.claude/skills/` và load các skill khi description match với task

### Bước 4: Bắt đầu làm việc

Ví dụ prompts:

```
Setup project Next.js 14 với cấu trúc trong CLAUDE.md
```

```
Tạo database schema cho catalog và order theo skill database-schema
```

```
Implement VNPay payment integration theo skill payment-vn
```

```
Tạo trang chi tiết sản phẩm theo skill ui-design và seo-optimization
```

## 📚 Tổng quan các Skills

| Skill | Trigger khi cần | Nội dung chính |
|-------|----------------|----------------|
| **ecommerce-architecture** | Thiết kế tổng thể, modules | 10 modules chính, state machine, layered architecture |
| **ui-design** | Build component, trang | Design tokens, ProductCard, mobile-first VN UX |
| **database-schema** | Tạo/sửa Prisma model | 15+ models, indexes, soft delete, transactions |
| **api-design** | Build API endpoint | Route Handlers, Zod validation, error handling, RBAC |
| **payment-vn** | Tích hợp thanh toán VN | VNPay HMAC, MoMo, ZaloPay, signature verify, idempotency |
| **seo-optimization** | SEO, metadata, sitemap | Next Metadata API, Schema.org, Cốc Cốc, Core Web Vitals |
| **security** | Auth, validation, file upload | bcrypt, RBAC, IDOR, XSS, OWASP Top 10 |
| **testing** | Viết tests | Vitest unit, RTL component, Playwright E2E |
| **deployment** | Deploy, CI/CD | Vercel, Supabase, GitHub Actions, monitoring |
| **git-workflow** | Branch, commit, PR | Conventional Commits, PR template, code review |

## 🇻🇳 Tối ưu cho Việt Nam

Hệ thống này được thiết kế đặc thù cho thị trường VN:

- **Thanh toán**: VNPay, MoMo, ZaloPay, COD (60-70% đơn hàng)
- **Vận chuyển**: GHN, GHTK với tính phí theo quận/huyện
- **Địa chỉ**: 63 tỉnh/thành, dataset Province → District → Ward
- **Tiền tệ**: Format `1.000.000₫` chuẩn VN
- **Mobile-first**: 70%+ traffic từ mobile, sticky add-to-cart
- **SEO**: Tối ưu cho Cốc Cốc Search ngoài Google, slug tiếng Việt
- **Compliance**: Nghị định 13/2023/NĐ-CP về dữ liệu cá nhân
- **Trust signals**: COD, đổi trả 7 ngày, hotline, chính hãng badges
- **Font**: Be Vietnam Pro / Inter (hỗ trợ dấu tiếng Việt tốt)

## 🛠️ Stack mặc định

Có thể đổi tùy nhu cầu, nhưng mặc định:

```
Frontend:     Next.js 14 (App Router) + TypeScript + Tailwind + shadcn/ui
State:        Zustand (client) + TanStack Query (server)
Database:     PostgreSQL + Prisma ORM
Auth:         NextAuth v5 (Auth.js)
Storage:      Cloudinary (images)
Cache:        Upstash Redis
Email:        Resend
Payment:      VNPay + MoMo + ZaloPay + COD
Shipping:     GHN + GHTK
Hosting:      Vercel + Supabase
Monitoring:   Sentry
Testing:      Vitest + RTL + Playwright
```

**Chi phí ước tính**: ~$60-100/tháng cho startup scale (10k MAU).

## 🎯 Customize theo dự án của bạn

### Nếu dùng stack khác (Laravel, Django, Rails...)

1. Giữ lại các skill **tech-agnostic**:
   - `ecommerce-architecture` — Logic nghiệp vụ, modules
   - `payment-vn` — Implementation detail có thể đổi nhưng concept giữ nguyên
   - `seo-optimization` — Metadata, schema.org áp dụng mọi stack
   - `security` — OWASP Top 10 áp dụng mọi nơi
   - `git-workflow` — Hoàn toàn tech-agnostic

2. Sửa lại các skill **stack-specific**:
   - `ui-design` — Đổi component examples sang Vue/React/Blade
   - `database-schema` — Đổi Prisma sang Eloquent/Django ORM
   - `api-design` — Đổi Route Handlers sang REST/GraphQL framework của bạn
   - `testing` — Đổi Vitest sang PHPUnit/pytest
   - `deployment` — Đổi Vercel sang stack hosting của bạn

### Nếu chỉ làm MVP

Có thể bỏ qua hoặc làm sau:
- Skill `testing` (làm sau khi feature ổn định)
- Skill `seo-optimization` (cơ bản đủ cho MVP)
- Phần multi-language trong các skill
- Admin panel phức tạp

### Nếu scale lớn (Enterprise)

Cân nhắc thêm:
- Microservices architecture (tách payment, search, recommendation)
- Event-driven (Kafka, RabbitMQ)
- Search engine (Algolia, Meilisearch, Elasticsearch)
- Multi-warehouse, multi-store
- B2B features (quote, RFQ, credit terms)

## 📖 Học thêm

- [Claude Code Documentation](https://docs.claude.com/en/docs/claude-code)
- [Skills Documentation](https://docs.claude.com/en/docs/claude-code/skills)
- [Conventional Commits](https://www.conventionalcommits.org/)
- [VNPay Developer Portal](https://sandbox.vnpayment.vn/apis/)
- [Next.js Docs](https://nextjs.org/docs)
- [Prisma Docs](https://www.prisma.io/docs)

## 📝 License

Bộ skill này dành cho nội bộ dự án. Tự do sửa đổi cho phù hợp nhu cầu.

---

**Lưu ý**: File `CLAUDE.md` ở root sẽ được Claude đọc đầu tiên trong mọi conversation. Các SKILL.md chỉ được load khi description match với context — đây là điểm khác biệt quan trọng giúp tiết kiệm context window.
