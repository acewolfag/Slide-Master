---
name: security
description: Use this skill for any security-related work including authentication, authorization, input validation, sanitization, CSRF/XSS prevention, rate limiting, and secrets management. Trigger when implementing auth flows, handling user input, or building admin features.
---

# Security Skill

## 🛡️ Security Mindset

**Quy tắc số 1:** Không bao giờ tin tưởng client. LUÔN validate, sanitize, authorize ở server.

## 🔐 Authentication

### Password Hashing - bcrypt
```typescript
import bcrypt from 'bcryptjs';

const SALT_ROUNDS = 12; // 10-12 cân bằng security/performance

// Hash
const hashedPassword = await bcrypt.hash(plainPassword, SALT_ROUNDS);

// Verify
const isValid = await bcrypt.compare(plainPassword, hashedPassword);

// LUÔN dùng timing-safe comparison cho tokens
import { timingSafeEqual } from 'crypto';
const isValid = timingSafeEqual(Buffer.from(token1), Buffer.from(token2));
```

### Password Requirements
```typescript
export const passwordSchema = z.string()
  .min(8, 'Mật khẩu tối thiểu 8 ký tự')
  .max(72, 'Mật khẩu tối đa 72 ký tự') // bcrypt limit
  .regex(/[A-Z]/, 'Phải có chữ hoa')
  .regex(/[a-z]/, 'Phải có chữ thường')
  .regex(/[0-9]/, 'Phải có số');
  // KHÔNG bắt buộc special char (UX)
```

### Session Management
```typescript
// NextAuth config
export const authOptions: NextAuthOptions = {
  session: {
    strategy: 'jwt',
    maxAge: 30 * 24 * 60 * 60, // 30 days
    updateAge: 24 * 60 * 60,   // refresh daily
  },
  cookies: {
    sessionToken: {
      name: '__Secure-next-auth.session-token',
      options: {
        httpOnly: true,        // Không access từ JS
        sameSite: 'lax',       // CSRF protection
        secure: true,          // HTTPS only
        path: '/',
      },
    },
  },
  // ...
};
```

### Brute Force Protection
```typescript
// Rate limit login attempts
const loginRateLimit = new Ratelimit({
  redis: Redis.fromEnv(),
  limiter: Ratelimit.slidingWindow(5, '15 m'), // 5 lần/15 phút
});

// Account lockout sau nhiều lần fail
async function recordFailedLogin(email: string) {
  const key = `failed-login:${email}`;
  const count = await redis.incr(key);
  await redis.expire(key, 900); // 15 min

  if (count >= 5) {
    await prisma.user.update({
      where: { email },
      data: { lockedUntil: new Date(Date.now() + 30 * 60 * 1000) },
    });
    // Send alert email
  }
}
```

### Email Verification
- Token với crypto.randomBytes(32)
- Hết hạn sau 1 giờ (cho registration), 24h (cho password reset)
- One-time use - delete sau khi verify
- Rate limit gửi email

## 🔑 Authorization

### Role-Based Access Control
```typescript
// lib/auth/permissions.ts
export const PERMISSIONS = {
  PRODUCT_READ: 'product:read',
  PRODUCT_WRITE: 'product:write',
  PRODUCT_DELETE: 'product:delete',
  ORDER_READ_ALL: 'order:read:all',
  ORDER_READ_OWN: 'order:read:own',
  ORDER_WRITE: 'order:write',
  ORDER_REFUND: 'order:refund',
  USER_READ: 'user:read',
  USER_WRITE: 'user:write',
  ADMIN: 'admin:*',
} as const;

export const ROLE_PERMISSIONS: Record<UserRole, string[]> = {
  CUSTOMER: ['product:read', 'order:read:own'],
  STAFF: ['product:read', 'order:read:all', 'order:write'],
  ADMIN: ['*:*'], // Tất cả trừ super admin actions
  SUPER_ADMIN: ['*'],
};

export function hasPermission(user: User, permission: string): boolean {
  const userPerms = ROLE_PERMISSIONS[user.role] || [];
  return userPerms.some(p => {
    if (p === '*') return true;
    if (p === permission) return true;
    if (p.endsWith(':*')) {
      const prefix = p.slice(0, -1);
      return permission.startsWith(prefix);
    }
    return false;
  });
}
```

### Resource-Level Authorization
```typescript
// User chỉ xem được order của mình, admin xem được tất cả
async function canViewOrder(user: User, orderId: string): Promise<boolean> {
  if (hasPermission(user, PERMISSIONS.ORDER_READ_ALL)) return true;

  if (hasPermission(user, PERMISSIONS.ORDER_READ_OWN)) {
    const order = await prisma.order.findUnique({
      where: { id: orderId },
      select: { userId: true },
    });
    return order?.userId === user.id;
  }

  return false;
}

// LUÔN check trong API
if (!(await canViewOrder(session.user, orderId))) {
  throw errors.FORBIDDEN();
}
```

### IDOR Prevention (Insecure Direct Object Reference)
```typescript
// ❌ BAD - User có thể xem order bất kỳ
const order = await prisma.order.findUnique({ where: { id: orderId } });

// ✅ GOOD - Filter theo userId luôn
const order = await prisma.order.findUnique({
  where: {
    id: orderId,
    userId: session.user.id, // Implicit ownership check
  },
});
```

## 🧹 Input Validation & Sanitization

### Validate với Zod ở MỌI entry point
```typescript
// Mọi API endpoint, mọi form submit
const schema = z.object({
  email: z.string().email().toLowerCase().trim(),
  name: z.string().min(2).max(100).trim(),
  age: z.number().int().min(13).max(120),
  url: z.string().url(),
  phone: z.string().regex(/^(0|\+84)\d{9,10}$/),
});

// LUÔN parse, không dùng safeParse trừ khi cần custom error
const data = schema.parse(input); // Throws ZodError nếu invalid
```

### XSS Prevention
```typescript
// 1. React auto-escape - DEFAULT SAFE
<div>{userInput}</div> // ✅ Safe

// 2. dangerouslySetInnerHTML - DANGEROUS
import DOMPurify from 'isomorphic-dompurify';

const cleanHTML = DOMPurify.sanitize(userInput, {
  ALLOWED_TAGS: ['p', 'br', 'strong', 'em', 'ul', 'ol', 'li', 'a'],
  ALLOWED_ATTR: ['href', 'target', 'rel'],
});

<div dangerouslySetInnerHTML={{ __html: cleanHTML }} />

// 3. URL inputs - validate scheme
function isSafeUrl(url: string): boolean {
  try {
    const parsed = new URL(url);
    return ['http:', 'https:'].includes(parsed.protocol);
  } catch {
    return false;
  }
}
```

### SQL Injection - Prisma đã handle
```typescript
// ✅ Prisma parameterizes tự động
const users = await prisma.user.findMany({
  where: { email: userInput }, // Safe
});

// ❌ Raw query - phải tự cẩn thận
await prisma.$queryRaw`SELECT * FROM users WHERE email = ${userInput}`; // Safe (tagged template)
await prisma.$queryRawUnsafe(`SELECT * FROM users WHERE email = '${userInput}'`); // ❌ DANGEROUS
```

### File Upload Security
```typescript
const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/webp'];
const MAX_SIZE = 5 * 1024 * 1024; // 5MB

async function validateUpload(file: File) {
  // 1. Check size
  if (file.size > MAX_SIZE) throw new Error('File quá lớn');

  // 2. Check MIME type
  if (!ALLOWED_TYPES.includes(file.type)) throw new Error('Định dạng không hỗ trợ');

  // 3. Check magic bytes (real type, không trust extension)
  const buffer = await file.arrayBuffer();
  const fileType = await fileTypeFromBuffer(buffer);
  if (!fileType || !ALLOWED_TYPES.includes(fileType.mime)) {
    throw new Error('File không hợp lệ');
  }

  // 4. Re-encode image (loại bỏ metadata, exploit)
  const sharp = await import('sharp');
  const sanitized = await sharp(buffer)
    .resize(2000, 2000, { fit: 'inside', withoutEnlargement: true })
    .jpeg({ quality: 85 })
    .toBuffer();

  return sanitized;
}

// Filename - generate, không dùng user input
const filename = `${Date.now()}-${randomUUID()}.jpg`;
```

## 🛡️ CSRF Protection

### NextAuth handles CSRF - đảm bảo dùng đúng
```typescript
// SameSite=Lax cookie default - tốt cho CSRF
// Plus CSRF token cho mutations

// Middleware check origin cho POST/PUT/DELETE
export function middleware(request: NextRequest) {
  const method = request.method;

  if (['POST', 'PUT', 'DELETE', 'PATCH'].includes(method)) {
    const origin = request.headers.get('origin');
    const host = request.headers.get('host');

    if (!origin || !origin.includes(host!)) {
      return NextResponse.json({ error: 'Invalid origin' }, { status: 403 });
    }
  }

  return NextResponse.next();
}
```

## 🔒 Secrets Management

### .env structure
```bash
# .env.local (NEVER COMMIT)
DATABASE_URL=
NEXTAUTH_SECRET=
NEXTAUTH_URL=

# Payment
VNPAY_TMN_CODE=
VNPAY_HASH_SECRET=
MOMO_PARTNER_CODE=
MOMO_ACCESS_KEY=
MOMO_SECRET_KEY=

# External services
CLOUDINARY_API_SECRET=
RESEND_API_KEY=
SENTRY_DSN=

# Redis
UPSTASH_REDIS_URL=
UPSTASH_REDIS_TOKEN=
```

### Quy tắc
- **KHÔNG** commit `.env*` (trừ `.env.example`)
- **KHÔNG** log secrets
- **KHÔNG** expose secrets ở frontend (`NEXT_PUBLIC_*` được expose!)
- **Rotate** secrets định kỳ
- **Use** Vercel env vars cho production
- **Encrypt** secrets at rest

### .gitignore
```
.env
.env.local
.env.*.local
*.pem
*.key
secrets/
```

## 🚦 Rate Limiting

```typescript
// Per-endpoint rate limits
export const rateLimits = {
  default: new Ratelimit({
    redis,
    limiter: Ratelimit.slidingWindow(100, '1 m'),
  }),

  // Stricter cho auth
  login: new Ratelimit({
    redis,
    limiter: Ratelimit.slidingWindow(5, '15 m'),
  }),

  register: new Ratelimit({
    redis,
    limiter: Ratelimit.slidingWindow(3, '1 h'),
  }),

  passwordReset: new Ratelimit({
    redis,
    limiter: Ratelimit.slidingWindow(3, '1 h'),
  }),

  // Checkout
  checkout: new Ratelimit({
    redis,
    limiter: Ratelimit.slidingWindow(10, '5 m'),
  }),

  // Search
  search: new Ratelimit({
    redis,
    limiter: Ratelimit.slidingWindow(30, '1 m'),
  }),
};

// Apply
const identifier = session?.user.id || getClientIp(request);
const { success, remaining } = await rateLimits.login.limit(identifier);

if (!success) {
  return NextResponse.json(
    { error: { code: 'RATE_LIMIT', message: 'Quá nhiều yêu cầu' } },
    {
      status: 429,
      headers: {
        'X-RateLimit-Remaining': String(remaining),
        'Retry-After': '60',
      },
    }
  );
}
```

## 🌐 Security Headers

```typescript
// next.config.js
const securityHeaders = [
  {
    key: 'Strict-Transport-Security',
    value: 'max-age=63072000; includeSubDomains; preload',
  },
  {
    key: 'X-Frame-Options',
    value: 'SAMEORIGIN',
  },
  {
    key: 'X-Content-Type-Options',
    value: 'nosniff',
  },
  {
    key: 'Referrer-Policy',
    value: 'strict-origin-when-cross-origin',
  },
  {
    key: 'Permissions-Policy',
    value: 'camera=(), microphone=(), geolocation=(self)',
  },
  {
    key: 'Content-Security-Policy',
    value: [
      "default-src 'self'",
      "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://www.googletagmanager.com",
      "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
      "img-src 'self' data: https: blob:",
      "font-src 'self' https://fonts.gstatic.com",
      "connect-src 'self' https://api.cloudinary.com",
      "frame-ancestors 'none'",
    ].join('; '),
  },
];

module.exports = {
  async headers() {
    return [{ source: '/(.*)', headers: securityHeaders }];
  },
};
```

## 💳 Payment Security

- **PCI DSS:** KHÔNG bao giờ lưu credit card numbers, CVV
- **Tokenization:** Dùng token từ payment gateway, không phải card raw
- **HTTPS:** Bắt buộc cho mọi payment flow
- **Webhook verification:** Verify signature mọi callback
- **Idempotency:** Dùng key để tránh double charge
- **Audit log:** Log mọi transaction (không log card data)

## 🔍 Logging & Monitoring

### Log levels
```typescript
import { logger } from '@/lib/logger';

logger.info('User logged in', { userId });
logger.warn('Low stock alert', { productId, stock });
logger.error('Payment failed', { orderId, error });
logger.audit('Admin action', { adminId, action: 'PRODUCT_DELETE', targetId });
```

### KHÔNG log
- ❌ Passwords (kể cả hash)
- ❌ Credit card numbers / CVV
- ❌ Personal IDs (CMND/CCCD)
- ❌ Full session tokens
- ❌ API secrets

### LOG (cho audit trail)
- ✅ Login attempts (success + fail)
- ✅ Password changes
- ✅ Permission changes
- ✅ Admin actions
- ✅ Payment events (transaction ID, không phải card)
- ✅ Data access (cho compliance)

## 🚨 Common Vulnerabilities Checklist

### OWASP Top 10
- [ ] **A01 Broken Access Control:** Test mọi endpoint với user khác nhau
- [ ] **A02 Cryptographic Failures:** HTTPS, bcrypt, không lưu sensitive data
- [ ] **A03 Injection:** Zod validation, Prisma parameterized
- [ ] **A04 Insecure Design:** Threat modeling, rate limiting
- [ ] **A05 Security Misconfiguration:** Headers, error messages không leak
- [ ] **A06 Vulnerable Components:** `npm audit` regular
- [ ] **A07 Auth Failures:** Strong password, MFA cho admin, lockout
- [ ] **A08 Data Integrity:** Verify webhook signatures, transactions
- [ ] **A09 Logging Failures:** Log security events, monitoring alerts
- [ ] **A10 SSRF:** Validate URLs, không fetch arbitrary URLs

### Pre-launch Security Audit
- [ ] All routes require auth/authorization (audit list)
- [ ] No hardcoded secrets in code
- [ ] HTTPS enforced (HSTS)
- [ ] Security headers configured
- [ ] Rate limiting on sensitive endpoints
- [ ] Input validation on every endpoint
- [ ] File uploads validated (type, size, content)
- [ ] Webhook signatures verified
- [ ] Error messages không leak info
- [ ] Dependencies updated, no known vulnerabilities
- [ ] Backup strategy in place
- [ ] Incident response plan
