---
name: api-design
description: Use this skill when creating, modifying, or designing API endpoints (REST, tRPC, or Next.js Route Handlers) for the e-commerce app. Covers validation, error handling, authentication, rate limiting, and API conventions.
---

# API Design Skill

## 🎯 API Architecture

**Approach:** Next.js Route Handlers (App Router) + tRPC cho internal, REST cho public/webhook

```
/api/
├── auth/                    # NextAuth
├── trpc/[trpc]/            # tRPC handler (internal)
├── webhooks/               # External webhooks (payment, shipping)
│   ├── vnpay/
│   ├── momo/
│   └── ghn/
├── public/                 # Public REST APIs
│   └── products/
└── admin/                  # Admin REST (nếu cần)
```

## 🛡️ Validation - LUÔN dùng Zod

```typescript
// schemas/product.schema.ts
import { z } from 'zod';

export const createProductSchema = z.object({
  name: z.string().min(3).max(200),
  slug: z.string().regex(/^[a-z0-9-]+$/),
  description: z.string().min(10),
  basePrice: z.number().positive().int(), // VND không có decimal
  salePrice: z.number().positive().int().optional(),
  categoryId: z.string().cuid(),
  brandId: z.string().cuid().optional(),
  stock: z.number().int().nonnegative(),
  images: z.array(z.string().url()).min(1).max(10),
  tags: z.array(z.string()).default([]),
}).refine(
  (data) => !data.salePrice || data.salePrice < data.basePrice,
  { message: 'Sale price must be less than base price', path: ['salePrice'] }
);

export type CreateProductInput = z.infer<typeof createProductSchema>;
```

## 📡 Route Handler Pattern

```typescript
// app/api/products/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/db';
import { auth } from '@/lib/auth';
import { rateLimit } from '@/lib/rate-limit';
import { createProductSchema } from '@/schemas/product.schema';

// GET /api/products
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);

    const querySchema = z.object({
      page: z.coerce.number().int().positive().default(1),
      limit: z.coerce.number().int().min(1).max(100).default(20),
      category: z.string().optional(),
      search: z.string().optional(),
      sort: z.enum(['newest', 'price-asc', 'price-desc', 'best-selling']).default('newest'),
    });

    const query = querySchema.parse(Object.fromEntries(searchParams));

    const where = {
      deletedAt: null,
      status: 'PUBLISHED' as const,
      ...(query.category && { category: { slug: query.category } }),
      ...(query.search && {
        OR: [
          { name: { contains: query.search, mode: 'insensitive' as const } },
          { tags: { has: query.search } },
        ]
      }),
    };

    const orderBy = {
      'newest': { createdAt: 'desc' as const },
      'price-asc': { basePrice: 'asc' as const },
      'price-desc': { basePrice: 'desc' as const },
      'best-selling': { soldCount: 'desc' as const },
    }[query.sort];

    const [products, total] = await Promise.all([
      prisma.product.findMany({
        where,
        orderBy,
        skip: (query.page - 1) * query.limit,
        take: query.limit,
        select: {
          id: true,
          slug: true,
          name: true,
          thumbnail: true,
          basePrice: true,
          salePrice: true,
          ratingAvg: true,
          ratingCount: true,
          soldCount: true,
        },
      }),
      prisma.product.count({ where }),
    ]);

    return NextResponse.json({
      data: products,
      pagination: {
        page: query.page,
        limit: query.limit,
        total,
        totalPages: Math.ceil(total / query.limit),
      },
    });
  } catch (error) {
    return handleApiError(error);
  }
}

// POST /api/products (admin only)
export async function POST(request: NextRequest) {
  try {
    // 1. Auth check
    const session = await auth();
    if (!session?.user || !['ADMIN', 'SUPER_ADMIN'].includes(session.user.role)) {
      return NextResponse.json(
        { error: { code: 'UNAUTHORIZED', message: 'Không có quyền' } },
        { status: 403 }
      );
    }

    // 2. Rate limit
    const { success } = await rateLimit.limit(session.user.id);
    if (!success) {
      return NextResponse.json(
        { error: { code: 'RATE_LIMIT', message: 'Quá nhiều yêu cầu' } },
        { status: 429 }
      );
    }

    // 3. Validate input
    const body = await request.json();
    const data = createProductSchema.parse(body);

    // 4. Business logic
    const product = await prisma.product.create({ data });

    // 5. Return
    return NextResponse.json({ data: product }, { status: 201 });
  } catch (error) {
    return handleApiError(error);
  }
}
```

## ❌ Error Handling - Standardized

```typescript
// lib/api-error.ts
export class ApiError extends Error {
  constructor(
    public code: string,
    public message: string,
    public statusCode: number,
    public details?: unknown
  ) {
    super(message);
  }
}

// Common errors
export const errors = {
  NOT_FOUND: (resource: string) =>
    new ApiError('NOT_FOUND', `${resource} không tồn tại`, 404),
  UNAUTHORIZED: () =>
    new ApiError('UNAUTHORIZED', 'Vui lòng đăng nhập', 401),
  FORBIDDEN: () =>
    new ApiError('FORBIDDEN', 'Không có quyền truy cập', 403),
  VALIDATION: (details: unknown) =>
    new ApiError('VALIDATION_ERROR', 'Dữ liệu không hợp lệ', 400, details),
  CONFLICT: (msg: string) =>
    new ApiError('CONFLICT', msg, 409),
  OUT_OF_STOCK: (productName: string) =>
    new ApiError('OUT_OF_STOCK', `${productName} đã hết hàng`, 409),
  PAYMENT_FAILED: (msg: string) =>
    new ApiError('PAYMENT_FAILED', msg, 402),
};

// Handler
export function handleApiError(error: unknown): NextResponse {
  // Zod validation errors
  if (error instanceof z.ZodError) {
    return NextResponse.json(
      {
        error: {
          code: 'VALIDATION_ERROR',
          message: 'Dữ liệu không hợp lệ',
          details: error.flatten().fieldErrors,
        }
      },
      { status: 400 }
    );
  }

  // Custom API errors
  if (error instanceof ApiError) {
    return NextResponse.json(
      { error: { code: error.code, message: error.message, details: error.details } },
      { status: error.statusCode }
    );
  }

  // Prisma errors
  if (error instanceof Prisma.PrismaClientKnownRequestError) {
    if (error.code === 'P2002') {
      return NextResponse.json(
        { error: { code: 'DUPLICATE', message: 'Dữ liệu đã tồn tại' } },
        { status: 409 }
      );
    }
  }

  // Unknown error - LOG nhưng KHÔNG expose
  console.error('Unhandled API error:', error);
  Sentry.captureException(error);

  return NextResponse.json(
    { error: { code: 'INTERNAL_ERROR', message: 'Có lỗi xảy ra, vui lòng thử lại' } },
    { status: 500 }
  );
}
```

## 🔐 Authentication & Authorization

### Middleware pattern
```typescript
// lib/api-middleware.ts
export async function withAuth(
  handler: (req: NextRequest, session: Session) => Promise<NextResponse>,
  options?: { roles?: UserRole[] }
) {
  return async (req: NextRequest) => {
    const session = await auth();

    if (!session?.user) {
      throw errors.UNAUTHORIZED();
    }

    if (options?.roles && !options.roles.includes(session.user.role)) {
      throw errors.FORBIDDEN();
    }

    return handler(req, session);
  };
}

// Usage
export const POST = withAuth(
  async (req, session) => { /* ... */ },
  { roles: ['ADMIN', 'SUPER_ADMIN'] }
);
```

### Resource ownership check
```typescript
// User chỉ được xem order của mình
const order = await prisma.order.findUnique({
  where: { id: orderId },
});

if (!order) throw errors.NOT_FOUND('Đơn hàng');

// Nếu không phải admin, check ownership
if (session.user.role === 'CUSTOMER' && order.userId !== session.user.id) {
  throw errors.FORBIDDEN();
}
```

## ⚡ Rate Limiting

```typescript
// lib/rate-limit.ts
import { Ratelimit } from '@upstash/ratelimit';
import { Redis } from '@upstash/redis';

export const rateLimit = new Ratelimit({
  redis: Redis.fromEnv(),
  limiter: Ratelimit.slidingWindow(100, '1 m'),
  analytics: true,
});

// Stricter limits cho sensitive endpoints
export const authRateLimit = new Ratelimit({
  redis: Redis.fromEnv(),
  limiter: Ratelimit.slidingWindow(5, '1 m'), // 5 lần/phút
});

export const checkoutRateLimit = new Ratelimit({
  redis: Redis.fromEnv(),
  limiter: Ratelimit.slidingWindow(3, '1 m'),
});
```

## 📨 Webhook Handling

```typescript
// app/api/webhooks/vnpay/route.ts
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    // 1. Verify signature - CRITICAL
    if (!verifyVNPaySignature(body)) {
      console.error('Invalid VNPay signature', body);
      return NextResponse.json({ error: 'Invalid signature' }, { status: 400 });
    }

    // 2. Idempotency - tránh xử lý 2 lần
    const existing = await prisma.payment.findFirst({
      where: { gatewayTransactionId: body.vnp_TransactionNo },
    });

    if (existing?.status === 'PAID') {
      return NextResponse.json({ RspCode: '00', Message: 'Already processed' });
    }

    // 3. Process trong transaction
    await prisma.$transaction(async (tx) => {
      // Update payment
      // Update order status
      // Trigger events
    });

    // 4. Return theo format VNPay yêu cầu
    return NextResponse.json({ RspCode: '00', Message: 'Confirm Success' });
  } catch (error) {
    console.error('VNPay webhook error', error);
    Sentry.captureException(error);
    return NextResponse.json({ RspCode: '99', Message: 'Internal Error' });
  }
}
```

## 📋 API Conventions

### URL naming
```
✅ GET    /api/products              # List
✅ GET    /api/products/{id}         # Detail
✅ POST   /api/products              # Create
✅ PATCH  /api/products/{id}         # Partial update
✅ PUT    /api/products/{id}         # Full update
✅ DELETE /api/products/{id}         # Delete

✅ POST   /api/orders/{id}/cancel    # Action verb
✅ GET    /api/users/me              # "me" thay vì ID
✅ GET    /api/products/{id}/reviews # Nested resource
```

### Response format
```typescript
// Success
{
  "data": { /* ... */ },
  "meta": { /* pagination, etc */ }
}

// Error
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Dữ liệu không hợp lệ",
    "details": { /* optional */ }
  }
}
```

### Status codes
- `200` - GET, PATCH, PUT thành công
- `201` - POST tạo mới thành công
- `204` - DELETE thành công
- `400` - Validation error
- `401` - Chưa đăng nhập
- `403` - Đăng nhập rồi nhưng không có quyền
- `404` - Resource không tồn tại
- `409` - Conflict (duplicate, out of stock)
- `429` - Rate limit
- `500` - Server error

## 🚀 Performance

### Cache headers
```typescript
// Static data - cache aggressive
return NextResponse.json(data, {
  headers: {
    'Cache-Control': 'public, s-maxage=3600, stale-while-revalidate=86400',
  },
});

// User data - no cache
return NextResponse.json(data, {
  headers: {
    'Cache-Control': 'private, no-cache, no-store, must-revalidate',
  },
});
```

### Field selection
```typescript
// ❌ Trả về quá nhiều
const products = await prisma.product.findMany();

// ✅ Chỉ trả fields cần thiết
const products = await prisma.product.findMany({
  select: { id: true, name: true, slug: true, thumbnail: true, basePrice: true }
});
```

### Avoid N+1
```typescript
// ❌ N+1 queries
const orders = await prisma.order.findMany();
for (const order of orders) {
  const items = await prisma.orderItem.findMany({ where: { orderId: order.id } });
}

// ✅ Single query với include
const orders = await prisma.order.findMany({
  include: { items: true }
});
```

## ✅ API Endpoint Checklist

- [ ] Validate input với Zod
- [ ] Check authentication (nếu cần)
- [ ] Check authorization (role + ownership)
- [ ] Rate limit (cho mutation và sensitive endpoints)
- [ ] Try-catch với handleApiError
- [ ] Type-safe response
- [ ] Pagination cho list endpoints
- [ ] Field selection để giảm payload
- [ ] Cache headers phù hợp
- [ ] Logging cho errors
- [ ] Test cả success và error cases
- [ ] Document trong OpenAPI/comment
