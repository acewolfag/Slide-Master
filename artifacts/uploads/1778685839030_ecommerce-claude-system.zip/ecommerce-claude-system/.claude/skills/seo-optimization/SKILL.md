---
name: seo-optimization
description: Use this skill when working on SEO, meta tags, structured data, sitemap, robots.txt, or content optimization for the e-commerce site. Covers Vietnamese SEO best practices, schema.org, Open Graph, and Core Web Vitals.
---

# SEO Optimization Skill

## 🎯 SEO Strategy cho E-commerce VN

### Mục tiêu chính
1. **Organic traffic** từ Google
2. **Rich snippets** trong search results (rating, price)
3. **Social sharing** đẹp (Facebook, Zalo)
4. **Core Web Vitals** xuất sắc

## 📝 Meta Tags - Next.js Metadata API

### Layout-level (defaults)
```typescript
// app/layout.tsx
import { Metadata } from 'next';

export const metadata: Metadata = {
  metadataBase: new URL('https://yourstore.vn'),
  title: {
    default: 'Yourstore - Mua sắm online giá tốt',
    template: '%s | Yourstore',
  },
  description: 'Cửa hàng online uy tín #1 Việt Nam. Giao hàng toàn quốc, đổi trả 7 ngày, thanh toán COD.',
  keywords: ['mua sắm online', 'thương mại điện tử', 'giao hàng nhanh'],
  authors: [{ name: 'Yourstore' }],
  creator: 'Yourstore',
  openGraph: {
    type: 'website',
    locale: 'vi_VN',
    url: 'https://yourstore.vn',
    siteName: 'Yourstore',
    images: [{ url: '/og-default.jpg', width: 1200, height: 630 }],
  },
  twitter: {
    card: 'summary_large_image',
    creator: '@yourstore',
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  verification: {
    google: 'your-google-verification-code',
  },
};
```

### Product Page (Dynamic)
```typescript
// app/(shop)/san-pham/[slug]/page.tsx
import { Metadata } from 'next';

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const product = await getProduct(params.slug);

  if (!product) return { title: 'Không tìm thấy sản phẩm' };

  const title = product.metaTitle || `${product.name} - Giá ${formatVND(product.salePrice || product.basePrice)}`;
  const description = product.metaDesc ||
    `${product.shortDesc || product.description.slice(0, 150)}... Mua ngay tại Yourstore. Giao hàng nhanh, đổi trả 7 ngày.`;

  return {
    title,
    description,
    keywords: [product.name, product.brand?.name, ...product.tags].filter(Boolean),
    alternates: {
      canonical: `/san-pham/${product.slug}`,
    },
    openGraph: {
      title,
      description,
      type: 'website', // OG không có 'product', dùng 'website'
      url: `/san-pham/${product.slug}`,
      images: product.images.map(img => ({
        url: img,
        width: 800,
        height: 800,
        alt: product.name,
      })),
    },
    twitter: {
      card: 'summary_large_image',
      title,
      description,
      images: [product.thumbnail],
    },
    other: {
      'product:price:amount': String(product.salePrice || product.basePrice),
      'product:price:currency': 'VND',
      'product:availability': product.stock > 0 ? 'in stock' : 'out of stock',
    },
  };
}
```

## 🏷️ Structured Data (Schema.org)

### Product
```typescript
// components/seo/ProductSchema.tsx
import { Product, Review } from '@prisma/client';

export function ProductSchema({ product }: { product: ProductWithDetails }) {
  const schema = {
    '@context': 'https://schema.org',
    '@type': 'Product',
    name: product.name,
    description: product.description,
    sku: product.sku,
    mpn: product.sku,
    brand: product.brand && {
      '@type': 'Brand',
      name: product.brand.name,
    },
    image: product.images,
    offers: {
      '@type': 'Offer',
      url: `https://yourstore.vn/san-pham/${product.slug}`,
      priceCurrency: 'VND',
      price: Number(product.salePrice || product.basePrice),
      priceValidUntil: '2026-12-31',
      availability: product.stock > 0
        ? 'https://schema.org/InStock'
        : 'https://schema.org/OutOfStock',
      itemCondition: 'https://schema.org/NewCondition',
      seller: {
        '@type': 'Organization',
        name: 'Yourstore',
      },
    },
    aggregateRating: product.ratingCount > 0 ? {
      '@type': 'AggregateRating',
      ratingValue: product.ratingAvg,
      reviewCount: product.ratingCount,
      bestRating: 5,
      worstRating: 1,
    } : undefined,
    review: product.reviews?.slice(0, 5).map(review => ({
      '@type': 'Review',
      reviewRating: {
        '@type': 'Rating',
        ratingValue: review.rating,
        bestRating: 5,
      },
      author: {
        '@type': 'Person',
        name: review.user.name,
      },
      datePublished: review.createdAt.toISOString(),
      reviewBody: review.content,
    })),
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
    />
  );
}
```

### BreadcrumbList
```typescript
export function BreadcrumbSchema({ items }: { items: BreadcrumbItem[] }) {
  const schema = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: items.map((item, index) => ({
      '@type': 'ListItem',
      position: index + 1,
      name: item.name,
      item: `https://yourstore.vn${item.href}`,
    })),
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
    />
  );
}
```

### Organization (Homepage)
```typescript
const orgSchema = {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  name: 'Yourstore',
  url: 'https://yourstore.vn',
  logo: 'https://yourstore.vn/logo.png',
  contactPoint: {
    '@type': 'ContactPoint',
    telephone: '+84-1900-xxxx',
    contactType: 'customer service',
    areaServed: 'VN',
    availableLanguage: 'Vietnamese',
  },
  sameAs: [
    'https://facebook.com/yourstore',
    'https://zalo.me/yourstore',
    'https://www.tiktok.com/@yourstore',
  ],
  address: {
    '@type': 'PostalAddress',
    streetAddress: '...',
    addressLocality: 'Hồ Chí Minh',
    addressCountry: 'VN',
  },
};
```

### LocalBusiness (nếu có store offline)
```typescript
const businessSchema = {
  '@context': 'https://schema.org',
  '@type': 'Store',
  name: 'Yourstore',
  image: 'https://yourstore.vn/store.jpg',
  '@id': 'https://yourstore.vn',
  url: 'https://yourstore.vn',
  telephone: '+84-xxx',
  address: { /* ... */ },
  geo: {
    '@type': 'GeoCoordinates',
    latitude: 10.7769,
    longitude: 106.7009,
  },
  openingHoursSpecification: {
    '@type': 'OpeningHoursSpecification',
    dayOfWeek: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
    opens: '08:00',
    closes: '22:00',
  },
};
```

## 🗺️ Sitemap & Robots

### sitemap.ts (Dynamic)
```typescript
// app/sitemap.ts
import { MetadataRoute } from 'next';
import { prisma } from '@/lib/db';

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const baseUrl = 'https://yourstore.vn';

  // Static pages
  const staticPages: MetadataRoute.Sitemap = [
    {
      url: baseUrl,
      lastModified: new Date(),
      changeFrequency: 'daily',
      priority: 1,
    },
    {
      url: `${baseUrl}/san-pham`,
      lastModified: new Date(),
      changeFrequency: 'daily',
      priority: 0.9,
    },
    {
      url: `${baseUrl}/gioi-thieu`,
      changeFrequency: 'monthly',
      priority: 0.5,
    },
  ];

  // Dynamic - products
  const products = await prisma.product.findMany({
    where: { status: 'PUBLISHED', deletedAt: null },
    select: { slug: true, updatedAt: true },
  });

  const productPages: MetadataRoute.Sitemap = products.map(p => ({
    url: `${baseUrl}/san-pham/${p.slug}`,
    lastModified: p.updatedAt,
    changeFrequency: 'weekly',
    priority: 0.8,
  }));

  // Categories
  const categories = await prisma.category.findMany({
    where: { isActive: true },
    select: { slug: true, updatedAt: true },
  });

  const categoryPages: MetadataRoute.Sitemap = categories.map(c => ({
    url: `${baseUrl}/danh-muc/${c.slug}`,
    lastModified: c.updatedAt,
    changeFrequency: 'daily',
    priority: 0.7,
  }));

  return [...staticPages, ...productPages, ...categoryPages];
}
```

### robots.ts
```typescript
// app/robots.ts
import { MetadataRoute } from 'next';

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      {
        userAgent: '*',
        allow: '/',
        disallow: [
          '/admin/',
          '/api/',
          '/auth/',
          '/checkout/',
          '/account/',
          '/cart',
          '/*?*', // No URLs with query params
        ],
      },
      {
        userAgent: 'GPTBot', // Block AI scrapers nếu muốn
        disallow: '/',
      },
    ],
    sitemap: 'https://yourstore.vn/sitemap.xml',
  };
}
```

## 🔗 URL Structure - SEO Friendly

### Best practices
```
✅ Tốt:
/san-pham/iphone-15-pro-max-256gb
/danh-muc/dien-thoai
/blog/cach-chon-iphone-tot-nhat
/khuyen-mai/black-friday-2026

❌ Xấu:
/product?id=12345
/category/đién-thoại (có dấu)
/p/abc-123-xyz (không readable)
```

### Slug generation
```typescript
import slugify from 'slugify';

export function generateSlug(text: string): string {
  return slugify(text, {
    lower: true,
    strict: true, // Remove special chars
    locale: 'vi',
  });
}

// Để unique - thêm ID ngắn nếu trùng
export async function generateUniqueSlug(name: string, model: 'product' | 'category'): Promise<string> {
  let slug = generateSlug(name);
  let counter = 0;

  while (await prisma[model].findUnique({ where: { slug } })) {
    counter++;
    slug = `${generateSlug(name)}-${counter}`;
  }

  return slug;
}
```

## 🖼️ Image SEO

### Best practices
```tsx
<Image
  src={product.image}
  alt={`${product.name} - ${product.brand?.name || 'Yourstore'}`}
  width={800}
  height={800}
  priority={isAboveFold} // LCP optimization
  quality={85}
  sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
/>
```

### Quy tắc
- **Alt text:** Mô tả nội dung, KHÔNG keyword stuff
- **Filename:** `iphone-15-pro-max-mau-titan-tu-nhien.webp` (kebab-case, descriptive)
- **Format:** WebP/AVIF (Next/Image tự convert)
- **Lazy load:** Default trong Next.js, tắt cho LCP image
- **Dimensions:** LUÔN khai báo width/height tránh CLS
- **Compress:** Quality 80-85 đủ tốt

## ⚡ Core Web Vitals

### LCP (Largest Contentful Paint) - Target < 2.5s
```typescript
// 1. Priority cho hero image
<Image src={heroImage} priority />

// 2. Preload critical fonts
import { Inter } from 'next/font/google';
const inter = Inter({ subsets: ['latin'], display: 'swap', preload: true });

// 3. ISR cho content pages
export const revalidate = 3600; // 1 hour
```

### CLS (Cumulative Layout Shift) - Target < 0.1
```typescript
// 1. LUÔN khai báo dimensions
<Image width={800} height={400} />
<iframe width="560" height="315" />

// 2. Reserve space cho ads/embeds
<div className="aspect-video" />

// 3. font-display: swap với fallback
const inter = Inter({
  subsets: ['latin'],
  display: 'swap',
  fallback: ['system-ui'],
});
```

### INP (Interaction to Next Paint) - Target < 200ms
```typescript
// 1. Code splitting
const HeavyComponent = dynamic(() => import('./HeavyComponent'));

// 2. Debounce input
const debouncedSearch = useDebouncedCallback(handleSearch, 300);

// 3. Optimistic updates
const handleAddToCart = async () => {
  setOptimisticCount(c => c + 1); // Update UI ngay
  await addToCart(); // Sync với server
};
```

## 📱 Mobile SEO

```html
<!-- Viewport -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5" />

<!-- Theme color cho mobile browsers -->
<meta name="theme-color" content="#dc2626" />

<!-- Apple touch icon -->
<link rel="apple-touch-icon" href="/apple-icon.png" />

<!-- Preconnect cho external domains -->
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://res.cloudinary.com" />
```

## 🇻🇳 Vietnamese SEO Tips

### Keywords research
- Dùng **Google Trends VN**, **Keyword Planner**
- Tool: Ahrefs, Semrush (có data VN)
- Long-tail: "iphone 15 pro max giá rẻ chính hãng" thay vì "iphone"
- Local intent: "+ tphcm", "+ hà nội", "+ giao hàng nhanh"

### Content
- **Tiêu đề:** 50-60 ký tự, có brand
- **Meta desc:** 150-160 ký tự, có CTA ("Mua ngay", "Xem giá")
- **H1:** 1 mỗi page, chứa keyword chính
- **H2-H3:** Hierarchical, có keyword phụ
- **Nội dung:** Tối thiểu 300 từ cho category, 500+ cho blog

### Technical SEO VN-specific
- **Bing Vietnam:** Submit sitemap (vẫn có user)
- **Cốc Cốc:** Trình duyệt phổ biến VN, hỗ trợ Webmaster Tools
- **Hreflang:** Nếu có đa ngôn ngữ: `vi-VN`, `en-US`

## 📊 SEO Checklist - Pre-Launch

### Technical
- [ ] Sitemap.xml dynamic, submit Google Search Console
- [ ] robots.txt đúng
- [ ] HTTPS với redirect HTTP → HTTPS
- [ ] Canonical URLs
- [ ] 404 page custom
- [ ] 301 redirects cho old URLs
- [ ] Structured data validate với Google Rich Results Test
- [ ] Open Graph test với Facebook Debugger
- [ ] Page speed > 90 (Lighthouse)
- [ ] Mobile-friendly test pass

### On-page
- [ ] Unique title cho mỗi page
- [ ] Unique meta description
- [ ] H1 hierarchy đúng
- [ ] Alt text cho mọi image
- [ ] Internal linking strategy
- [ ] Breadcrumbs navigation
- [ ] Related products links

### Content
- [ ] Product descriptions unique (không copy)
- [ ] Category pages có introduction text
- [ ] Blog/Tin tức section (content marketing)
- [ ] About page chi tiết
- [ ] Contact page với địa chỉ + map

### Off-page
- [ ] Google Business Profile setup
- [ ] Social profiles (Facebook, Zalo OA, TikTok)
- [ ] Submit lên các shopping platforms (Google Shopping)
- [ ] Backlink strategy

## 🎯 Monitoring

### Tools setup
- **Google Search Console** - Index status, queries, errors
- **Google Analytics 4** - Traffic, conversions
- **Vercel Analytics** - Web Vitals real users
- **Ahrefs/Semrush** - Rankings, competitors

### KPIs to track
- Organic traffic month-over-month
- Top landing pages
- Top queries (impressions, clicks, CTR)
- Average position
- Core Web Vitals scores
- Conversion rate from organic
