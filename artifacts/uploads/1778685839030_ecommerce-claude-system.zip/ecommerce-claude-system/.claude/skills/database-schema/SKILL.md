---
name: database-schema
description: Use this skill when designing or modifying database schemas, writing Prisma migrations, or making decisions about data modeling for the e-commerce app. Covers Prisma schema patterns, relations, indexes, and migration best practices.
---

# Database Schema Skill

## 🎯 Nguyên tắc thiết kế

1. **Tính nhất quán:** Mọi bảng có `id`, `createdAt`, `updatedAt`
2. **Soft delete:** Dùng `deletedAt` cho dữ liệu quan trọng (orders, users, products)
3. **Foreign keys:** LUÔN có `onDelete` rule rõ ràng
4. **Indexes:** Index cho mọi field thường query (FK, search, sort)
5. **Naming:** `snake_case` cho DB, `camelCase` trong code (Prisma `@map`)

## 📊 Core Schema (Prisma)

```prisma
// schema.prisma

generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

// ============ USER ============
model User {
  id          String    @id @default(cuid())
  email       String    @unique
  phone       String?   @unique
  name        String
  password    String?   // null nếu đăng nhập OAuth
  avatar      String?
  role        UserRole  @default(CUSTOMER)
  emailVerifiedAt DateTime?
  phoneVerifiedAt DateTime?

  // Relations
  addresses   Address[]
  orders      Order[]
  reviews     Review[]
  cartItems   CartItem[]
  wishlist    WishlistItem[]
  vouchersUsed VoucherUsage[]

  createdAt   DateTime  @default(now())
  updatedAt   DateTime  @updatedAt
  deletedAt   DateTime?

  @@index([email])
  @@index([phone])
  @@index([role])
  @@map("users")
}

enum UserRole {
  CUSTOMER
  STAFF
  ADMIN
  SUPER_ADMIN
}

// ============ ADDRESS ============
model Address {
  id          String  @id @default(cuid())
  userId      String
  user        User    @relation(fields: [userId], references: [id], onDelete: Cascade)

  recipientName String
  phone       String
  province    String  // Tỉnh/Thành phố
  district    String  // Quận/Huyện
  ward        String  // Phường/Xã
  street      String  // Số nhà, tên đường
  note        String?

  isDefault   Boolean @default(false)

  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt

  @@index([userId])
  @@map("addresses")
}

// ============ CATEGORY ============
model Category {
  id          String    @id @default(cuid())
  name        String
  slug        String    @unique
  description String?
  image       String?
  parentId    String?
  parent      Category? @relation("CategoryHierarchy", fields: [parentId], references: [id])
  children    Category[] @relation("CategoryHierarchy")

  // Materialized path: "/electronics/phones/smartphones"
  path        String    @default("/")
  level       Int       @default(0)
  order       Int       @default(0)

  products    Product[]

  isActive    Boolean   @default(true)
  createdAt   DateTime  @default(now())
  updatedAt   DateTime  @updatedAt

  @@index([slug])
  @@index([parentId])
  @@index([path])
  @@map("categories")
}

// ============ PRODUCT ============
model Product {
  id          String   @id @default(cuid())
  sku         String   @unique
  slug        String   @unique
  name        String
  description String   @db.Text
  shortDesc   String?

  // Pricing
  basePrice   Decimal  @db.Decimal(12, 2)
  salePrice   Decimal? @db.Decimal(12, 2)
  costPrice   Decimal? @db.Decimal(12, 2) // For profit calculation

  // Inventory
  trackStock  Boolean  @default(true)
  stock       Int      @default(0)
  lowStockThreshold Int @default(5)

  // Display
  images      String[] // Array of URLs
  thumbnail   String

  // Relations
  categoryId  String
  category    Category @relation(fields: [categoryId], references: [id])
  brandId     String?
  brand       Brand?   @relation(fields: [brandId], references: [id])

  variants    ProductVariant[]
  reviews     Review[]
  orderItems  OrderItem[]
  cartItems   CartItem[]
  wishlist    WishlistItem[]

  // SEO
  metaTitle   String?
  metaDesc    String?
  ogImage     String?

  // Stats (denormalized for performance)
  viewCount   Int      @default(0)
  soldCount   Int      @default(0)
  ratingAvg   Float    @default(0)
  ratingCount Int      @default(0)

  // Tags & search
  tags        String[]
  searchVector Unsupported("tsvector")?

  // Status
  status      ProductStatus @default(DRAFT)
  publishedAt DateTime?

  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
  deletedAt   DateTime?

  @@index([slug])
  @@index([categoryId, status])
  @@index([brandId])
  @@index([status, publishedAt])
  @@index([soldCount])
  @@index([ratingAvg])
  @@map("products")
}

enum ProductStatus {
  DRAFT
  PUBLISHED
  ARCHIVED
  OUT_OF_STOCK
}

model ProductVariant {
  id          String  @id @default(cuid())
  productId   String
  product     Product @relation(fields: [productId], references: [id], onDelete: Cascade)

  sku         String  @unique
  name        String  // VD: "Đen - Size L"
  attributes  Json    // { color: "Đen", size: "L" }
  price       Decimal @db.Decimal(12, 2)
  salePrice   Decimal? @db.Decimal(12, 2)
  stock       Int     @default(0)
  image       String?

  cartItems   CartItem[]
  orderItems  OrderItem[]

  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt

  @@index([productId])
  @@map("product_variants")
}

// ============ BRAND ============
model Brand {
  id          String   @id @default(cuid())
  name        String   @unique
  slug        String   @unique
  logo        String?
  description String?

  products    Product[]

  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt

  @@index([slug])
  @@map("brands")
}

// ============ CART ============
model CartItem {
  id        String   @id @default(cuid())
  userId    String?
  user      User?    @relation(fields: [userId], references: [id], onDelete: Cascade)
  sessionId String?  // For guest carts

  productId String
  product   Product  @relation(fields: [productId], references: [id])
  variantId String?
  variant   ProductVariant? @relation(fields: [variantId], references: [id])

  quantity  Int

  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt

  @@unique([userId, productId, variantId])
  @@unique([sessionId, productId, variantId])
  @@index([userId])
  @@index([sessionId])
  @@map("cart_items")
}

// ============ WISHLIST ============
model WishlistItem {
  id        String   @id @default(cuid())
  userId    String
  user      User     @relation(fields: [userId], references: [id], onDelete: Cascade)
  productId String
  product   Product  @relation(fields: [productId], references: [id], onDelete: Cascade)

  createdAt DateTime @default(now())

  @@unique([userId, productId])
  @@index([userId])
  @@map("wishlist_items")
}

// ============ ORDER ============
model Order {
  id            String   @id @default(cuid())
  orderNumber   String   @unique // ORD-20260502-00001
  userId        String?
  user          User?    @relation(fields: [userId], references: [id])

  // Snapshot dữ liệu lúc đặt (vì address/user có thể đổi)
  recipientName String
  recipientPhone String
  recipientEmail String?
  shippingAddress Json   // Snapshot full address

  // Items
  items         OrderItem[]

  // Pricing
  subtotal      Decimal  @db.Decimal(12, 2) // Tổng giá hàng
  shippingFee   Decimal  @db.Decimal(12, 2)
  discount      Decimal  @db.Decimal(12, 2) @default(0)
  tax           Decimal  @db.Decimal(12, 2) @default(0)
  total         Decimal  @db.Decimal(12, 2) // Tổng phải trả

  // Voucher
  voucherCode   String?
  voucherDiscount Decimal? @db.Decimal(12, 2)

  // Status
  status        OrderStatus @default(PENDING)
  paymentStatus PaymentStatus @default(PENDING)
  paymentMethod PaymentMethod

  // Shipping
  shippingMethod String
  trackingCode  String?
  shippedAt     DateTime?
  deliveredAt   DateTime?

  // Cancellation
  cancelledAt   DateTime?
  cancelReason  String?

  // Note
  customerNote  String?
  internalNote  String?

  // Payment
  payments      Payment[]

  // Voucher usage
  voucherUsages VoucherUsage[]

  createdAt     DateTime @default(now())
  updatedAt     DateTime @updatedAt

  @@index([orderNumber])
  @@index([userId, createdAt])
  @@index([status])
  @@index([paymentStatus])
  @@index([createdAt])
  @@map("orders")
}

enum OrderStatus {
  PENDING       // Chờ xác nhận
  CONFIRMED     // Đã xác nhận
  PROCESSING    // Đang chuẩn bị
  SHIPPING      // Đang giao
  DELIVERED     // Đã giao
  CANCELLED     // Đã hủy
  RETURNED      // Đã trả hàng
}

enum PaymentStatus {
  PENDING       // Chưa thanh toán
  PAID          // Đã thanh toán
  FAILED        // Thất bại
  REFUNDED      // Đã hoàn tiền
  PARTIAL_REFUNDED
}

enum PaymentMethod {
  COD           // Thanh toán khi nhận hàng
  VNPAY
  MOMO
  ZALOPAY
  BANK_TRANSFER
}

model OrderItem {
  id          String  @id @default(cuid())
  orderId     String
  order       Order   @relation(fields: [orderId], references: [id], onDelete: Cascade)

  productId   String
  product     Product @relation(fields: [productId], references: [id])
  variantId   String?
  variant     ProductVariant? @relation(fields: [variantId], references: [id])

  // Snapshot lúc đặt hàng
  productName String
  variantName String?
  productImage String
  sku         String

  quantity    Int
  unitPrice   Decimal @db.Decimal(12, 2)
  totalPrice  Decimal @db.Decimal(12, 2)

  // Review
  reviewId    String? @unique
  review      Review? @relation(fields: [reviewId], references: [id])

  createdAt   DateTime @default(now())

  @@index([orderId])
  @@index([productId])
  @@map("order_items")
}

// ============ PAYMENT ============
model Payment {
  id              String   @id @default(cuid())
  orderId         String
  order           Order    @relation(fields: [orderId], references: [id])

  method          PaymentMethod
  amount          Decimal  @db.Decimal(12, 2)
  status          PaymentStatus

  // Gateway info
  gatewayTransactionId String?  // VNPay TxnRef, MoMo orderId, etc.
  gatewayResponse Json?         // Full response for audit
  paidAt          DateTime?

  // Idempotency
  idempotencyKey  String?  @unique

  createdAt       DateTime @default(now())
  updatedAt       DateTime @updatedAt

  @@index([orderId])
  @@index([gatewayTransactionId])
  @@index([status])
  @@map("payments")
}

// ============ REVIEW ============
model Review {
  id        String   @id @default(cuid())
  userId    String
  user      User     @relation(fields: [userId], references: [id])
  productId String
  product   Product  @relation(fields: [productId], references: [id], onDelete: Cascade)

  rating    Int      // 1-5
  title     String?
  content   String   @db.Text
  images    String[]

  // Moderation
  isVerified Boolean @default(false) // Mua thật
  isApproved Boolean @default(false)
  isHidden   Boolean @default(false)

  // Linked to order item
  orderItem OrderItem?

  // Helpful count
  helpfulCount Int @default(0)

  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt

  @@unique([userId, productId])
  @@index([productId, isApproved])
  @@map("reviews")
}

// ============ VOUCHER ============
model Voucher {
  id              String   @id @default(cuid())
  code            String   @unique
  name            String
  description     String?

  type            VoucherType
  value           Decimal  @db.Decimal(12, 2) // % hoặc số tiền
  maxDiscount     Decimal? @db.Decimal(12, 2) // Giảm tối đa (cho %)
  minOrderValue   Decimal? @db.Decimal(12, 2)

  usageLimit      Int?     // Tổng lượt dùng
  usageCount      Int      @default(0)
  usagePerUser    Int      @default(1)

  validFrom       DateTime
  validTo         DateTime

  // Áp dụng cho
  applicableProductIds  String[]
  applicableCategoryIds String[]
  userType        UserType @default(ALL)

  isActive        Boolean  @default(true)

  usages          VoucherUsage[]

  createdAt       DateTime @default(now())
  updatedAt       DateTime @updatedAt

  @@index([code])
  @@index([isActive, validFrom, validTo])
  @@map("vouchers")
}

enum VoucherType {
  PERCENTAGE      // Giảm %
  FIXED_AMOUNT    // Giảm cố định
  FREE_SHIPPING   // Miễn phí ship
}

enum UserType {
  ALL
  NEW             // User mới
  VIP             // User VIP
}

model VoucherUsage {
  id        String  @id @default(cuid())
  voucherId String
  voucher   Voucher @relation(fields: [voucherId], references: [id])
  userId    String
  user      User    @relation(fields: [userId], references: [id])
  orderId   String
  order     Order   @relation(fields: [orderId], references: [id])

  discountAmount Decimal @db.Decimal(12, 2)

  createdAt DateTime @default(now())

  @@unique([voucherId, userId, orderId])
  @@index([voucherId])
  @@index([userId])
  @@map("voucher_usages")
}

// ============ INVENTORY LOG ============
model InventoryLog {
  id          String   @id @default(cuid())
  productId   String
  variantId   String?

  type        InventoryLogType
  quantity    Int      // Có thể âm
  reason      String?
  referenceId String?  // Order ID, etc.

  beforeStock Int
  afterStock  Int

  createdBy   String?  // User ID

  createdAt   DateTime @default(now())

  @@index([productId])
  @@index([type])
  @@index([createdAt])
  @@map("inventory_logs")
}

enum InventoryLogType {
  PURCHASE      // Nhập hàng
  SALE          // Bán hàng
  RETURN        // Trả hàng
  ADJUSTMENT    // Điều chỉnh
  DAMAGED       // Hỏng
}

// ============ SESSION (NextAuth) ============
model Account {
  id                String  @id @default(cuid())
  userId            String
  type              String
  provider          String
  providerAccountId String
  refresh_token     String? @db.Text
  access_token      String? @db.Text
  expires_at        Int?
  token_type        String?
  scope             String?
  id_token          String? @db.Text
  session_state     String?

  @@unique([provider, providerAccountId])
  @@map("accounts")
}

model VerificationToken {
  identifier String
  token      String   @unique
  expires    DateTime

  @@unique([identifier, token])
  @@map("verification_tokens")
}
```

## 🔑 Quy tắc Migration

### Tạo migration
```bash
# Dev
npx prisma migrate dev --name add_voucher_table

# Production
npx prisma migrate deploy
```

### Naming convention
- `add_<table>_table` - Tạo bảng mới
- `add_<column>_to_<table>` - Thêm cột
- `update_<table>_<change>` - Đổi cấu trúc
- `seed_<data>` - Seed data

### Quy tắc bắt buộc
1. **KHÔNG BAO GIỜ** edit migration đã apply lên production
2. **LUÔN backup** trước khi migrate production
3. **Test migration** trên staging trước
4. **Reversible:** Migration phải có thể rollback
5. **Atomic:** Mỗi migration là 1 logical change

### Breaking Changes Strategy
Khi thêm cột NOT NULL vào bảng có data:
```
Step 1: Add column nullable
Step 2: Backfill data (script)
Step 3: Add NOT NULL constraint
```

## 📏 Indexing Strategy

### LUÔN index
- Foreign keys (Prisma không auto index)
- Fields trong WHERE thường dùng
- Fields trong ORDER BY
- Unique fields (slug, code, email)

### Composite index khi
- Query có nhiều WHERE conditions
- VD: `[categoryId, status]` cho query products by category

### KHÔNG index
- Fields hiếm khi query
- Bảng nhỏ (< 1000 rows)
- Boolean với cardinality thấp

## 🔄 Common Patterns

### Soft Delete với Prisma
```typescript
// Mọi query LUÔN filter deletedAt
const products = await prisma.product.findMany({
  where: { deletedAt: null }
});

// Helper
const where = { deletedAt: null, ...userFilters };
```

### Pagination - Cursor based (cho list lớn)
```typescript
const products = await prisma.product.findMany({
  take: 20,
  cursor: cursorId ? { id: cursorId } : undefined,
  skip: cursorId ? 1 : 0,
  orderBy: { createdAt: 'desc' }
});
```

### Transaction (cho operations liên quan)
```typescript
await prisma.$transaction(async (tx) => {
  // 1. Tạo order
  const order = await tx.order.create({ data: orderData });

  // 2. Tạo order items
  await tx.orderItem.createMany({ data: items });

  // 3. Giảm stock
  for (const item of items) {
    await tx.product.update({
      where: { id: item.productId },
      data: { stock: { decrement: item.quantity } }
    });
  }

  // 4. Log inventory
  await tx.inventoryLog.createMany({ data: logs });

  return order;
});
```

### Optimistic Locking (cho stock)
```typescript
const result = await prisma.product.updateMany({
  where: {
    id: productId,
    stock: { gte: quantity } // Chỉ update nếu đủ stock
  },
  data: {
    stock: { decrement: quantity }
  }
});

if (result.count === 0) {
  throw new Error('Out of stock');
}
```

## ✅ Checklist Schema mới

- [ ] Có `id`, `createdAt`, `updatedAt`?
- [ ] Cần soft delete? Thêm `deletedAt`
- [ ] Foreign keys có `onDelete` rule?
- [ ] Indexes đầy đủ cho query patterns?
- [ ] Unique constraints đúng?
- [ ] Decimal cho money (KHÔNG dùng Float)?
- [ ] Enum thay vì String cho fixed values?
- [ ] `@map` để có tên DB snake_case?
- [ ] Comment cho fields phức tạp?
- [ ] Migration test được rollback?
