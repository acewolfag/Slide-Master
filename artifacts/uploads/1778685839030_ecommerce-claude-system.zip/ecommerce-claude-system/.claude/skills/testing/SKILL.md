---
name: testing
description: Use this skill when writing tests for the e-commerce app, including unit tests, integration tests, and E2E tests. Covers Vitest, React Testing Library, Playwright patterns, and testing strategies for critical e-commerce flows.
---

# Testing Skill

## 🎯 Testing Strategy

### Pyramid
```
        ┌──────────┐
        │   E2E    │  10% - Critical flows (checkout, auth)
        ├──────────┤
        │Integration│ 30% - API endpoints, components
        ├──────────┤
        │   Unit   │  60% - Utils, logic, schemas
        └──────────┘
```

### Tools
- **Vitest** - Unit + Integration (nhanh hơn Jest)
- **React Testing Library** - Component testing
- **Playwright** - E2E (multi-browser, hỗ trợ tốt)
- **MSW** - Mock API requests
- **Faker.js** - Test data generation

## 🧪 Unit Tests

### Setup
```typescript
// vitest.config.ts
import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';
import path from 'path';

export default defineConfig({
  plugins: [react()],
  test: {
    environment: 'jsdom',
    setupFiles: ['./tests/setup.ts'],
    globals: true,
    coverage: {
      provider: 'v8',
      reporter: ['text', 'html', 'lcov'],
      exclude: ['node_modules/', 'tests/', '.next/'],
      thresholds: {
        lines: 70,
        functions: 70,
        branches: 70,
        statements: 70,
      },
    },
  },
  resolve: {
    alias: { '@': path.resolve(__dirname, './src') },
  },
});
```

### Test Utilities
```typescript
// tests/setup.ts
import '@testing-library/jest-dom/vitest';
import { cleanup } from '@testing-library/react';
import { afterEach, vi } from 'vitest';

afterEach(() => cleanup());

// Mock Next.js
vi.mock('next/navigation', () => ({
  useRouter: () => ({ push: vi.fn(), replace: vi.fn() }),
  usePathname: () => '/',
  useSearchParams: () => new URLSearchParams(),
}));

vi.mock('next/image', () => ({
  default: (props: any) => <img {...props} />,
}));
```

### Pure Functions
```typescript
// lib/utils/__tests__/format.test.ts
import { describe, it, expect } from 'vitest';
import { formatVND, formatDate, generateOrderNumber } from '../format';

describe('formatVND', () => {
  it('formats positive numbers', () => {
    expect(formatVND(1000000)).toBe('1.000.000\u00A0₫');
  });

  it('formats zero', () => {
    expect(formatVND(0)).toBe('0\u00A0₫');
  });

  it('handles decimals (rounds)', () => {
    expect(formatVND(1000.5)).toBe('1.001\u00A0₫');
  });
});

describe('generateOrderNumber', () => {
  it('follows format ORD-YYYYMMDD-XXXXX', () => {
    const orderNum = generateOrderNumber(123, new Date('2026-05-02'));
    expect(orderNum).toBe('ORD-20260502-00123');
  });

  it('pads sequence to 5 digits', () => {
    expect(generateOrderNumber(1, new Date('2026-05-02'))).toBe('ORD-20260502-00001');
  });
});
```

### Business Logic
```typescript
// lib/cart/__tests__/calculator.test.ts
import { describe, it, expect } from 'vitest';
import { calculateCartTotal, applyVoucher } from '../calculator';

describe('calculateCartTotal', () => {
  const items = [
    { price: 100000, quantity: 2 },
    { price: 50000, quantity: 1 },
  ];

  it('calculates subtotal correctly', () => {
    const result = calculateCartTotal({ items, shippingFee: 30000 });
    expect(result.subtotal).toBe(250000);
    expect(result.total).toBe(280000);
  });

  it('applies fixed discount', () => {
    const result = calculateCartTotal({
      items,
      shippingFee: 30000,
      voucher: { type: 'FIXED', value: 50000 },
    });
    expect(result.discount).toBe(50000);
    expect(result.total).toBe(230000);
  });

  it('applies percentage discount with max', () => {
    const result = calculateCartTotal({
      items,
      shippingFee: 30000,
      voucher: { type: 'PERCENTAGE', value: 50, maxDiscount: 100000 },
    });
    expect(result.discount).toBe(100000); // Cap tại max
  });

  it('applies free shipping voucher', () => {
    const result = calculateCartTotal({
      items,
      shippingFee: 30000,
      voucher: { type: 'FREE_SHIPPING' },
    });
    expect(result.shippingFee).toBe(0);
    expect(result.total).toBe(250000);
  });

  it('does not allow negative total', () => {
    const result = calculateCartTotal({
      items: [{ price: 10000, quantity: 1 }],
      shippingFee: 0,
      voucher: { type: 'FIXED', value: 100000 },
    });
    expect(result.total).toBe(0);
    expect(result.discount).toBe(10000); // Discount giới hạn ở subtotal
  });
});
```

### Schemas (Zod)
```typescript
// schemas/__tests__/product.test.ts
import { describe, it, expect } from 'vitest';
import { createProductSchema } from '../product.schema';

describe('createProductSchema', () => {
  const validInput = {
    name: 'iPhone 15',
    slug: 'iphone-15',
    description: 'A great phone with many features',
    basePrice: 25000000,
    categoryId: 'clxxx0000000000000000',
    stock: 100,
    images: ['https://example.com/img.jpg'],
  };

  it('accepts valid input', () => {
    const result = createProductSchema.safeParse(validInput);
    expect(result.success).toBe(true);
  });

  it('rejects negative price', () => {
    const result = createProductSchema.safeParse({ ...validInput, basePrice: -100 });
    expect(result.success).toBe(false);
  });

  it('rejects sale price >= base price', () => {
    const result = createProductSchema.safeParse({
      ...validInput,
      basePrice: 100,
      salePrice: 100,
    });
    expect(result.success).toBe(false);
  });

  it('rejects invalid slug format', () => {
    const result = createProductSchema.safeParse({ ...validInput, slug: 'Invalid Slug!' });
    expect(result.success).toBe(false);
  });
});
```

## 🧩 Component Tests

```typescript
// components/__tests__/ProductCard.test.tsx
import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { ProductCard } from '../ProductCard';

const mockProduct = {
  id: '1',
  slug: 'iphone-15',
  name: 'iPhone 15',
  thumbnail: 'https://example.com/iphone.jpg',
  basePrice: 25000000,
  salePrice: 22000000,
  ratingAvg: 4.5,
  ratingCount: 100,
  soldCount: 1500,
};

describe('ProductCard', () => {
  it('renders product name and prices', () => {
    render(<ProductCard product={mockProduct} />);

    expect(screen.getByText('iPhone 15')).toBeInTheDocument();
    expect(screen.getByText(/22\.000\.000/)).toBeInTheDocument();
    expect(screen.getByText(/25\.000\.000/)).toBeInTheDocument(); // crossed-out
  });

  it('shows sale percentage when on sale', () => {
    render(<ProductCard product={mockProduct} />);

    // (25M - 22M) / 25M = 12%
    expect(screen.getByText('-12%')).toBeInTheDocument();
  });

  it('does not show sale badge for non-sale products', () => {
    render(<ProductCard product={{ ...mockProduct, salePrice: null }} />);
    expect(screen.queryByText(/-\d+%/)).not.toBeInTheDocument();
  });

  it('calls onAddToCart when button clicked', async () => {
    const onAddToCart = vi.fn();
    const user = userEvent.setup();

    render(<ProductCard product={mockProduct} onAddToCart={onAddToCart} />);

    await user.click(screen.getByRole('button', { name: /thêm vào giỏ/i }));
    expect(onAddToCart).toHaveBeenCalledWith(mockProduct.id);
  });

  it('has proper alt text for accessibility', () => {
    render(<ProductCard product={mockProduct} />);
    expect(screen.getByAltText('iPhone 15')).toBeInTheDocument();
  });

  it('links to product detail page', () => {
    render(<ProductCard product={mockProduct} />);
    const link = screen.getByRole('link');
    expect(link).toHaveAttribute('href', '/san-pham/iphone-15');
  });
});
```

## 🌐 API Integration Tests

```typescript
// app/api/products/__tests__/route.test.ts
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { GET, POST } from '../route';
import { prisma } from '@/lib/db';
import { createMocks } from 'node-mocks-http';

describe('/api/products', () => {
  beforeEach(async () => {
    await prisma.product.deleteMany();
    await prisma.category.deleteMany();

    // Seed
    await prisma.category.create({ data: { id: 'cat1', name: 'Phones', slug: 'phones' } });
    await prisma.product.createMany({
      data: [
        {
          sku: 'IP15',
          slug: 'iphone-15',
          name: 'iPhone 15',
          description: 'Great phone',
          basePrice: 20000000,
          categoryId: 'cat1',
          thumbnail: 'img.jpg',
          images: ['img.jpg'],
          status: 'PUBLISHED',
        },
      ],
    });
  });

  describe('GET', () => {
    it('returns published products', async () => {
      const request = new Request('http://localhost/api/products');
      const response = await GET(request as any);
      const data = await response.json();

      expect(response.status).toBe(200);
      expect(data.data).toHaveLength(1);
      expect(data.data[0].slug).toBe('iphone-15');
    });

    it('filters by category', async () => {
      const request = new Request('http://localhost/api/products?category=phones');
      const response = await GET(request as any);
      const data = await response.json();

      expect(data.data).toHaveLength(1);
    });

    it('paginates correctly', async () => {
      const request = new Request('http://localhost/api/products?page=1&limit=10');
      const response = await GET(request as any);
      const data = await response.json();

      expect(data.pagination).toMatchObject({
        page: 1,
        limit: 10,
        total: 1,
        totalPages: 1,
      });
    });

    it('rejects invalid query params', async () => {
      const request = new Request('http://localhost/api/products?page=abc');
      const response = await GET(request as any);
      expect(response.status).toBe(400);
    });
  });

  describe('POST', () => {
    it('requires authentication', async () => {
      // Mock no session
      const request = new Request('http://localhost/api/products', {
        method: 'POST',
        body: JSON.stringify({}),
      });
      const response = await POST(request as any);
      expect(response.status).toBe(403); // Hoặc 401
    });

    it('creates product with valid input as admin', async () => {
      // Mock admin session
      vi.mocked(auth).mockResolvedValue({
        user: { id: 'admin1', role: 'ADMIN' },
      });

      const request = new Request('http://localhost/api/products', {
        method: 'POST',
        body: JSON.stringify({
          name: 'Test Product',
          slug: 'test-product',
          description: 'Test description',
          basePrice: 100000,
          categoryId: 'cat1',
          stock: 10,
          images: ['https://example.com/img.jpg'],
        }),
      });

      const response = await POST(request as any);
      expect(response.status).toBe(201);
    });
  });
});
```

## 🎭 E2E Tests (Playwright)

### Setup
```typescript
// playwright.config.ts
import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  testDir: './e2e',
  fullyParallel: true,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 1 : undefined,
  reporter: 'html',

  use: {
    baseURL: process.env.E2E_BASE_URL || 'http://localhost:3000',
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
    locale: 'vi-VN',
  },

  projects: [
    { name: 'chromium', use: { ...devices['Desktop Chrome'] } },
    { name: 'mobile', use: { ...devices['iPhone 13'] } }, // VN: 80% mobile
  ],

  webServer: {
    command: 'npm run dev',
    url: 'http://localhost:3000',
    reuseExistingServer: !process.env.CI,
  },
});
```

### Critical Flows

#### Checkout Flow
```typescript
// e2e/checkout.spec.ts
import { test, expect } from '@playwright/test';

test.describe('Checkout Flow', () => {
  test.beforeEach(async ({ page }) => {
    // Login as test user
    await page.goto('/auth/signin');
    await page.fill('[name=email]', 'test@example.com');
    await page.fill('[name=password]', 'Test1234');
    await page.click('button[type=submit]');
    await page.waitForURL('/');
  });

  test('user can complete a purchase with COD', async ({ page }) => {
    // 1. Add product to cart
    await page.goto('/san-pham/test-product');
    await page.click('button:has-text("Thêm vào giỏ")');

    await expect(page.getByText('Đã thêm vào giỏ hàng')).toBeVisible();

    // 2. Go to cart
    await page.click('a[href="/cart"]');
    await expect(page.getByText('Test Product')).toBeVisible();

    // 3. Proceed to checkout
    await page.click('button:has-text("Thanh toán")');

    // 4. Fill shipping info
    await page.fill('[name=recipientName]', 'Nguyễn Văn A');
    await page.fill('[name=phone]', '0901234567');
    await page.selectOption('[name=province]', 'TP. Hồ Chí Minh');
    await page.selectOption('[name=district]', 'Quận 1');
    await page.selectOption('[name=ward]', 'Phường Bến Nghé');
    await page.fill('[name=street]', '123 Đường ABC');

    // 5. Select COD
    await page.click('input[value=COD]');

    // 6. Place order
    await page.click('button:has-text("Đặt hàng")');

    // 7. Verify success
    await page.waitForURL(/\/orders\/ORD-/);
    await expect(page.getByText(/Đặt hàng thành công/)).toBeVisible();
    await expect(page.getByText(/ORD-/)).toBeVisible();
  });

  test('cannot checkout with empty cart', async ({ page }) => {
    await page.goto('/checkout');
    await expect(page).toHaveURL('/cart');
    await expect(page.getByText('Giỏ hàng trống')).toBeVisible();
  });

  test('shows error when stock insufficient', async ({ page }) => {
    // Add product with only 1 stock left
    // Try to set quantity to 5
    // ... assert error message
  });
});
```

#### Authentication
```typescript
// e2e/auth.spec.ts
test.describe('Authentication', () => {
  test('user can register and login', async ({ page }) => {
    const email = `test-${Date.now()}@example.com`;

    // Register
    await page.goto('/auth/signup');
    await page.fill('[name=name]', 'Test User');
    await page.fill('[name=email]', email);
    await page.fill('[name=phone]', '0901234567');
    await page.fill('[name=password]', 'Test1234');
    await page.click('button[type=submit]');

    await page.waitForURL('/');
    await expect(page.getByText(/Test User/)).toBeVisible();
  });

  test('shows error for invalid credentials', async ({ page }) => {
    await page.goto('/auth/signin');
    await page.fill('[name=email]', 'wrong@example.com');
    await page.fill('[name=password]', 'wrong');
    await page.click('button[type=submit]');

    await expect(page.getByText(/Email hoặc mật khẩu không đúng/)).toBeVisible();
  });

  test('rate limits login attempts', async ({ page }) => {
    await page.goto('/auth/signin');

    for (let i = 0; i < 6; i++) {
      await page.fill('[name=email]', 'test@example.com');
      await page.fill('[name=password]', 'wrong');
      await page.click('button[type=submit]');
      await page.waitForTimeout(100);
    }

    await expect(page.getByText(/Quá nhiều yêu cầu/)).toBeVisible();
  });
});
```

## 🎯 Test Data Factories

```typescript
// tests/factories/index.ts
import { faker } from '@faker-js/faker';

export const productFactory = (overrides?: Partial<Product>): Product => ({
  id: faker.string.uuid(),
  sku: faker.string.alphanumeric(8).toUpperCase(),
  slug: faker.helpers.slugify(faker.commerce.productName()).toLowerCase(),
  name: faker.commerce.productName(),
  description: faker.commerce.productDescription(),
  basePrice: faker.number.int({ min: 10000, max: 50000000 }),
  salePrice: null,
  stock: faker.number.int({ min: 0, max: 100 }),
  thumbnail: faker.image.url(),
  images: [faker.image.url()],
  status: 'PUBLISHED',
  categoryId: faker.string.uuid(),
  createdAt: new Date(),
  updatedAt: new Date(),
  ...overrides,
});

export const userFactory = (overrides?: Partial<User>): User => ({
  id: faker.string.uuid(),
  email: faker.internet.email(),
  name: faker.person.fullName(),
  phone: '09' + faker.string.numeric(8),
  role: 'CUSTOMER',
  password: '$2a$12$hashedpassword',
  createdAt: new Date(),
  updatedAt: new Date(),
  ...overrides,
});
```

## 📋 What to Test

### MUST test (Priority 1)
- ✅ Payment flow (mock gateway)
- ✅ Cart calculation logic
- ✅ Order creation
- ✅ Stock decrement on order
- ✅ Voucher application rules
- ✅ Authentication & authorization
- ✅ API input validation
- ✅ Webhook signature verification

### SHOULD test (Priority 2)
- ✅ Search & filter logic
- ✅ Pagination
- ✅ Email sending (mock)
- ✅ Form validation
- ✅ Critical UI components

### NICE to test (Priority 3)
- Static pages render
- Visual regression (Chromatic, Percy)
- Performance benchmarks

## ❌ DON'T test
- Third-party libraries (trust them)
- Implementation details (test behavior)
- Trivial getters/setters
- Static configuration

## ✅ Testing Best Practices

1. **AAA Pattern:** Arrange, Act, Assert
2. **One thing per test:** Mỗi test verify 1 hành vi
3. **Descriptive names:** `it('returns 404 when product not found')`
4. **No test interdependence:** Mỗi test độc lập
5. **Use factories:** Không hardcode test data
6. **Clean up:** Reset DB/state sau mỗi test
7. **Mock external:** APIs, databases trong unit tests
8. **Real DB cho integration:** Test container hoặc test DB
9. **Fast feedback:** Unit tests phải chạy < 5s
10. **CI/CD:** Run tests trên mỗi PR
