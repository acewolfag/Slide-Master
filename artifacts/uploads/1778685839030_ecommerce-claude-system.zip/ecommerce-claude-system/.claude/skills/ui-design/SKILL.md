---
name: ui-design
description: Use this skill when designing or building UI components, pages, or layouts for the e-commerce site. Triggers include creating product cards, checkout forms, navigation, modals, or any visual component. Covers design system, accessibility, responsive design, and Vietnamese UX patterns.
---

# UI Design Skill

## 🎨 Design Philosophy

**Nguyên tắc:** Clarity > Cleverness. Người dùng VN ưu tiên dễ hiểu, dễ thao tác hơn là design "ngầu".

## 🎯 Design Tokens

### Colors (Tailwind config)
```typescript
// tailwind.config.ts
colors: {
  // Primary - màu thương hiệu
  primary: {
    50:  '#fef2f2',
    500: '#ef4444',  // Đỏ - màu phổ biến cho e-commerce VN
    600: '#dc2626',
    700: '#b91c1c',
  },
  // Secondary
  secondary: {
    500: '#f59e0b',  // Vàng cam - CTA mạnh
  },
  // Semantic
  success: '#10b981',
  warning: '#f59e0b',
  error:   '#ef4444',
  info:    '#3b82f6',
  // Sale badge
  sale:    '#ef4444',
}
```

### Typography
```css
/* Sans-serif: Inter, Be Vietnam Pro (hỗ trợ tốt tiếng Việt) */
font-family: 'Be Vietnam Pro', 'Inter', system-ui, sans-serif;

/* Scale */
text-xs:   12px  /* labels, captions */
text-sm:   14px  /* body small, meta */
text-base: 16px  /* body */
text-lg:   18px  /* emphasized body */
text-xl:   20px  /* h4 */
text-2xl:  24px  /* h3 */
text-3xl:  30px  /* h2 */
text-4xl:  36px  /* h1 */
```

### Spacing System
- Dùng Tailwind default (4px base)
- **Section padding:** `py-12 md:py-16 lg:py-20`
- **Container:** `max-w-7xl mx-auto px-4 md:px-6 lg:px-8`
- **Card padding:** `p-4 md:p-6`

### Border Radius
- `rounded-md` (6px) - buttons, inputs
- `rounded-lg` (8px) - cards
- `rounded-xl` (12px) - modals, prominent cards
- `rounded-full` - avatars, badges

### Shadows
- `shadow-sm` - subtle (cards default)
- `shadow-md` - cards on hover
- `shadow-lg` - modals, dropdowns
- `shadow-xl` - rarely, only for floating CTAs

## 📱 Responsive Breakpoints

```
sm:  640px   - mobile landscape
md:  768px   - tablet
lg:  1024px  - desktop
xl:  1280px  - large desktop
2xl: 1536px  - extra large
```

**Mobile-first:** Default styles cho mobile, dùng `md:`, `lg:` để override.

## 🧩 Component Patterns

### Product Card
```tsx
<article className="group rounded-lg border bg-white overflow-hidden hover:shadow-md transition">
  {/* Image với aspect ratio cố định */}
  <div className="relative aspect-square overflow-hidden bg-gray-100">
    <Image
      src={product.image}
      alt={product.name}
      fill
      className="object-cover group-hover:scale-105 transition-transform duration-300"
      sizes="(max-width: 768px) 50vw, 25vw"
    />
    {product.salePercent && (
      <span className="absolute top-2 left-2 bg-red-500 text-white text-xs px-2 py-1 rounded">
        -{product.salePercent}%
      </span>
    )}
  </div>

  {/* Content */}
  <div className="p-4">
    <h3 className="text-sm font-medium line-clamp-2 mb-2 min-h-[2.5rem]">
      {product.name}
    </h3>

    {/* Rating */}
    <div className="flex items-center gap-1 text-xs text-gray-600 mb-2">
      <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
      <span>{product.rating}</span>
      <span>({product.reviewCount})</span>
      <span className="ml-auto">Đã bán {product.soldCount}</span>
    </div>

    {/* Price */}
    <div className="flex items-baseline gap-2">
      <span className="text-lg font-bold text-red-600">
        {formatVND(product.salePrice)}
      </span>
      {product.salePrice < product.price && (
        <span className="text-xs text-gray-400 line-through">
          {formatVND(product.price)}
        </span>
      )}
    </div>
  </div>
</article>
```

### Button Variants
```tsx
// Primary CTA - "Mua ngay", "Thanh toán"
<button className="bg-red-600 hover:bg-red-700 text-white font-semibold px-6 py-3 rounded-md transition">
  Mua ngay
</button>

// Secondary - "Thêm vào giỏ"
<button className="border-2 border-red-600 text-red-600 hover:bg-red-50 font-semibold px-6 py-3 rounded-md transition">
  Thêm vào giỏ
</button>

// Ghost - actions phụ
<button className="text-gray-600 hover:text-gray-900 hover:bg-gray-100 px-4 py-2 rounded-md transition">
  Xem thêm
</button>
```

### Form Input
```tsx
<div className="space-y-1">
  <label className="text-sm font-medium text-gray-700">
    Số điện thoại <span className="text-red-500">*</span>
  </label>
  <input
    type="tel"
    className="w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-red-500 focus:border-red-500 outline-none transition"
    placeholder="Nhập số điện thoại"
  />
  {error && (
    <p className="text-xs text-red-500">{error}</p>
  )}
</div>
```

## 🎯 Critical UX Patterns cho E-commerce VN

### 1. Sticky "Add to Cart" trên mobile
```tsx
<div className="fixed bottom-0 left-0 right-0 bg-white border-t p-3 md:hidden z-40">
  <div className="flex gap-2">
    <button className="flex-1 border-2 border-red-600 text-red-600 py-3 rounded-md font-semibold">
      Thêm vào giỏ
    </button>
    <button className="flex-1 bg-red-600 text-white py-3 rounded-md font-semibold">
      Mua ngay
    </button>
  </div>
</div>
```

### 2. Loading States - LUÔN dùng skeleton, không spinner
```tsx
// ProductCardSkeleton
<div className="rounded-lg border bg-white overflow-hidden animate-pulse">
  <div className="aspect-square bg-gray-200" />
  <div className="p-4 space-y-2">
    <div className="h-4 bg-gray-200 rounded w-3/4" />
    <div className="h-4 bg-gray-200 rounded w-1/2" />
    <div className="h-6 bg-gray-200 rounded w-1/3 mt-3" />
  </div>
</div>
```

### 3. Empty States - Có actionable
```tsx
<div className="flex flex-col items-center py-16 text-center">
  <ShoppingCart className="w-16 h-16 text-gray-300 mb-4" />
  <h3 className="text-lg font-semibold mb-2">Giỏ hàng trống</h3>
  <p className="text-gray-600 mb-6">
    Bạn chưa có sản phẩm nào trong giỏ hàng
  </p>
  <Link href="/" className="bg-red-600 text-white px-6 py-3 rounded-md">
    Tiếp tục mua sắm
  </Link>
</div>
```

### 4. Error States
```tsx
<div className="flex items-start gap-3 p-4 bg-red-50 border border-red-200 rounded-md">
  <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
  <div className="flex-1">
    <p className="font-medium text-red-900">Có lỗi xảy ra</p>
    <p className="text-sm text-red-700 mt-1">{errorMessage}</p>
    <button className="text-sm text-red-700 underline mt-2">
      Thử lại
    </button>
  </div>
</div>
```

### 5. Toast Notifications
- **Position:** top-right (desktop), top (mobile)
- **Duration:** 3s cho info, 5s cho error
- **Dismissable:** LUÔN có nút X
- **Library:** `sonner` hoặc `react-hot-toast`

## ♿ Accessibility (A11Y)

### Bắt buộc
- **Semantic HTML:** Dùng `<button>`, `<nav>`, `<main>`, `<article>`, không phải `<div>` cho mọi thứ
- **Alt text:** Mọi `<img>` có alt mô tả (sản phẩm: tên sản phẩm)
- **ARIA labels:** Cho icon buttons không có text
- **Keyboard nav:** Mọi interactive element focus được, có visible focus state
- **Color contrast:** Text/bg ratio >= 4.5:1 (text thường), >= 3:1 (text lớn)
- **Form labels:** Liên kết với input qua `htmlFor`/`id`
- **Error messages:** `aria-describedby` link tới error text

### Test
- Dùng keyboard tab qua toàn bộ page
- Dùng screen reader (VoiceOver Mac, NVDA Windows)
- Lighthouse Accessibility score >= 95

## 🌐 Internationalization

### Format helpers
```typescript
// Currency VND
export const formatVND = (amount: number): string => {
  return new Intl.NumberFormat('vi-VN', {
    style: 'currency',
    currency: 'VND',
    maximumFractionDigits: 0,
  }).format(amount);
};
// Output: 1.000.000 ₫

// Number
export const formatNumber = (n: number): string => {
  return new Intl.NumberFormat('vi-VN').format(n);
};

// Date
export const formatDate = (date: Date): string => {
  return new Intl.DateTimeFormat('vi-VN', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  }).format(date);
};
// Output: 02/05/2026

// Relative time
export const formatRelative = (date: Date): string => {
  // "5 phút trước", "2 giờ trước", "3 ngày trước"
};
```

## 🎬 Animations - Tinh tế, không lạm dụng

### Khi nào dùng
- ✅ Page transitions (fade in)
- ✅ Hover states (scale, shadow)
- ✅ Loading skeletons (pulse)
- ✅ Add to cart (icon bay vào giỏ - "delight")
- ✅ Success confirmations (checkmark animation)

### Khi nào KHÔNG dùng
- ❌ Animation > 500ms cho UI thường (gây chậm cảm nhận)
- ❌ Auto-playing sliders (annoying, kém SEO)
- ❌ Parallax scroll (phá vỡ flow mobile)
- ❌ Pop-up animation cho modal phải > 200ms

### Library
- **Framer Motion** cho animation phức tạp
- **Tailwind transitions** cho hover/focus đơn giản

## 📐 Layout Patterns

### Homepage
```
┌─────────────────────────────┐
│ Header (sticky)              │
├─────────────────────────────┤
│ Hero Banner (carousel/static)│
├─────────────────────────────┤
│ Flash Sale (countdown)       │
├─────────────────────────────┤
│ Categories (icon grid)       │
├─────────────────────────────┤
│ Featured Products             │
├─────────────────────────────┤
│ New Arrivals                  │
├─────────────────────────────┤
│ Best Sellers                  │
├─────────────────────────────┤
│ Brand Showcase                │
├─────────────────────────────┤
│ Newsletter / CTA              │
├─────────────────────────────┤
│ Footer                        │
└─────────────────────────────┘
```

### Product Detail Page
```
┌──────────────┬──────────────┐
│              │ Title         │
│  Image       │ Price         │
│  Gallery     │ Rating | Sold │
│              │ Variants      │
│              │ Quantity      │
│              │ [Add] [Buy]   │
├──────────────┴──────────────┤
│ Description Tab | Reviews Tab│
├─────────────────────────────┤
│ Related Products             │
└─────────────────────────────┘
```

## 🔥 Conversion Optimization

### Trust signals (đặc biệt quan trọng VN)
- Số lượng đã bán: "Đã bán 1.5k"
- Rating + reviews count
- "Freeship" badge nếu áp dụng
- "Trả hàng 7 ngày" badge
- Hotline 24/7 prominently displayed
- Logo các phương thức thanh toán ở footer

### Urgency/Scarcity (ethical)
- Flash sale countdown
- "Còn 3 sản phẩm" khi stock thấp
- "12 người đang xem" (real-time)

### Reduce friction
- Guest checkout (không bắt đăng ký)
- Auto-fill địa chỉ qua API VN
- Saved cards (encrypted)
- One-click reorder

## ✅ Component Checklist

Trước khi commit component mới:
- [ ] Mobile responsive (test 375px, 768px, 1440px)
- [ ] Loading state có skeleton
- [ ] Error state có message rõ ràng
- [ ] Empty state nếu applicable
- [ ] Hover/focus states
- [ ] Keyboard navigable
- [ ] ARIA labels cho icons
- [ ] Alt text cho images
- [ ] No layout shift (CLS = 0)
- [ ] Dark mode (nếu site hỗ trợ)
- [ ] TypeScript types đầy đủ
- [ ] Props có default values hợp lý
