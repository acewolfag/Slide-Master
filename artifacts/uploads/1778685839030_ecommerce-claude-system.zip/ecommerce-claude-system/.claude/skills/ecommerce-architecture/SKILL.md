---
name: ecommerce-architecture
description: Use this skill when designing e-commerce system architecture, business flows, or making decisions about feature structure. Triggers include designing checkout flow, cart logic, product catalog, order management, inventory, or any high-level architectural decisions for the shop.
---

# E-commerce Architecture Skill

## 🎯 Mục đích
Hướng dẫn thiết kế kiến trúc hệ thống thương mại điện tử với best practices, áp dụng cho thị trường Việt Nam.

## 🏛️ Kiến trúc tổng thể

### Layered Architecture
```
┌─────────────────────────────────────┐
│  Presentation (Next.js Pages/API)    │
├─────────────────────────────────────┤
│  Application (Use Cases / Services)  │
├─────────────────────────────────────┤
│  Domain (Business Logic / Entities)  │
├─────────────────────────────────────┤
│  Infrastructure (DB, External APIs)  │
└─────────────────────────────────────┘
```

### Module chính
1. **Catalog** - Quản lý sản phẩm, danh mục, biến thể
2. **Cart** - Giỏ hàng (guest + authenticated)
3. **Checkout** - Quy trình đặt hàng
4. **Order** - Quản lý đơn hàng
5. **Payment** - Cổng thanh toán
6. **Shipping** - Vận chuyển và tracking
7. **User** - Tài khoản, địa chỉ, lịch sử
8. **Promotion** - Voucher, flash sale, combo
9. **Review** - Đánh giá sản phẩm
10. **Admin** - Dashboard quản trị

## 📦 Catalog Module

### Product Structure
```typescript
Product {
  id, slug, name, description, brand
  category[], tags[]
  images[] (multiple với alt text)
  basePrice, salePrice
  variants[] (size, color, material...)
  stock, sku
  seo { metaTitle, metaDesc, ogImage }
  status: draft | published | archived
}

ProductVariant {
  id, productId
  attributes { color, size, ... }
  price, stock, sku
  images[] (variant-specific)
}
```

### Best Practices
- **Slug:** auto-generate từ name, unique, kebab-case không dấu
  - VD: "Áo Thun Nam" → `ao-thun-nam-{shortId}`
- **Categories:** Hỗ trợ nested (cây danh mục) với materialized path
- **Search:** PostgreSQL Full-text Search hoặc Algolia/Meilisearch
- **Filtering:** Faceted search (giá, brand, attribute)
- **Sorting:** newest, price-asc, price-desc, best-selling, rating

## 🛒 Cart Module

### Strategy
- **Guest cart:** localStorage + Cookie session ID
- **User cart:** Database, persist across devices
- **Merge logic:** Khi đăng nhập, merge guest cart vào user cart
  - Conflict: ưu tiên item trong user cart, cộng quantity nếu cùng SKU

### Cart Item Validation (CRITICAL)
```
Mỗi lần load cart và trước checkout:
1. Check sản phẩm còn tồn tại không (chưa archive)
2. Check stock đủ không
3. Recalculate price (có thể đã đổi)
4. Apply lại promotions còn hiệu lực
5. Notify user nếu có thay đổi
```

## 💳 Checkout Flow

### Steps
```
1. Cart Review (xem lại giỏ hàng)
2. Shipping Info (địa chỉ + phương thức ship)
3. Payment Method (chọn thanh toán)
4. Order Confirmation (xác nhận)
5. Payment Processing
6. Success/Failure Page
```

### Quy tắc bắt buộc
- **Idempotency:** Mọi POST checkout có `idempotencyKey`
- **Server-side calculation:** KHÔNG BAO GIỜ trust giá từ client
- **Stock reservation:** Reserve stock trong 15 phút khi vào checkout
- **Address validation:** Verify với GHN/GHTK API
- **Tax calculation:** Theo quy định VAT Việt Nam (10% hoặc 0% tùy ngành)

## 📋 Order Module

### State Machine
```
pending → confirmed → processing → shipping → delivered
   ↓          ↓            ↓           ↓
cancelled  cancelled   cancelled   returned
```

### Quy tắc transition
- `pending → confirmed`: Sau khi payment thành công (hoặc COD verify)
- `confirmed → processing`: Admin xác nhận, chuẩn bị hàng
- `processing → shipping`: Bàn giao đơn vị vận chuyển
- `shipping → delivered`: Carrier xác nhận giao thành công
- Các bước có thể `cancel` với rules riêng (đã ship thì không cancel được)

### Order Number
- Format: `ORD-YYYYMMDD-XXXXX` (XXXXX là sequence)
- VD: `ORD-20260502-00001`
- Hiển thị cho user thay vì internal UUID

## 🚚 Shipping Module

### Tích hợp đơn vị vận chuyển VN
- **GHN (Giao Hàng Nhanh):** API tốt, phổ biến
- **GHTK (Giao Hàng Tiết Kiệm):** Giá rẻ, phù hợp shop nhỏ
- **Viettel Post, J&T:** Tùy nhu cầu

### Functions cần có
```typescript
- getShippingFee(from, to, weight, value): Promise<Fee>
- createShippingOrder(order): Promise<TrackingCode>
- trackShipment(code): Promise<Status>
- cancelShipment(code): Promise<void>
```

### Lưu ý
- Cache shipping fee trong 5-10 phút (giá có thể đổi)
- Webhook để nhận status update từ carrier
- Backup plan nếu API carrier down

## 🎁 Promotion Module

### Types
1. **Voucher code:** User nhập mã, giảm giá / freeship
2. **Auto-discount:** Áp dụng tự động (mua 2 tặng 1)
3. **Flash sale:** Giảm giá theo thời gian
4. **Combo:** Mua sản phẩm A + B giảm X%
5. **Loyalty:** Tích điểm đổi quà

### Validation Rules
```
- minOrderValue (đơn tối thiểu)
- maxDiscount (giảm tối đa)
- usageLimit (tổng lượt dùng)
- usagePerUser (mỗi user dùng tối đa)
- validFrom, validTo
- categoryIds[] / productIds[] (áp dụng cho sản phẩm nào)
- userType (new | vip | all)
- combinable (có cộng dồn voucher khác không)
```

### Apply Order (CRITICAL)
```
1. Apply auto-discounts trước
2. Apply voucher code sau
3. Tính phí ship (có thể được freeship)
4. Tính tax cuối cùng
```

## 👤 User Module

### Authentication
- **Methods:** Email/password, Google OAuth, số điện thoại + OTP
- **Password:** bcrypt với salt rounds >= 10
- **Session:** JWT (httpOnly cookie) hoặc database session
- **2FA:** Optional cho admin

### User Types
- `customer` - Khách hàng thường
- `staff` - Nhân viên (xem đơn, support)
- `admin` - Quản trị toàn quyền
- `super_admin` - Có thể quản lý admin khác

### Role-based Access Control (RBAC)
```typescript
Permissions:
- product.read, product.write, product.delete
- order.read, order.write, order.refund
- user.read, user.write, user.ban
- analytics.read, settings.write
```

## ⭐ Review Module

### Rules
- Chỉ user **đã mua** sản phẩm mới được review
- 1 review per user per product (cho phép edit)
- Rating 1-5 sao + nội dung + ảnh (optional)
- Admin moderate trước khi public (hoặc auto với keyword filter)
- Hiển thị verified purchase badge

## 📊 Admin Dashboard

### Modules cần có
1. **Overview:** Doanh thu, đơn hàng, traffic theo ngày/tháng
2. **Products:** CRUD, bulk import/export, inventory
3. **Orders:** List, filter, update status, refund
4. **Customers:** List, lifetime value, ban/unban
5. **Marketing:** Voucher, banner, popup, email campaign
6. **Reports:** Sales by product/category, customer cohort
7. **Settings:** Shipping, payment, store info

## 🔄 Event-Driven Patterns

### Domain Events
```typescript
- OrderPlaced → trigger: send email, reduce stock, notify admin
- PaymentSucceeded → trigger: confirm order, create shipping
- OrderShipped → trigger: send tracking email
- OrderDelivered → trigger: ask review (after 3 days)
- StockLow → trigger: notify admin
```

### Implementation
- Đơn giản: Function calls trong service
- Phức tạp: Message queue (BullMQ với Redis)
- Webhook: Cho external systems (analytics, CRM)

## 🚀 Performance Considerations

### Caching Strategy
- **Static pages:** ISR với revalidate 60s (homepage, category)
- **Product page:** ISR với on-demand revalidation khi update
- **API:** Redis cache cho:
  - Product list (5 min)
  - Categories tree (1 hour)
  - Shipping fee (10 min per route)
- **CDN:** CloudFlare cho static assets

### Database Optimization
- **Indexes:**
  - `products.slug` (unique)
  - `products.categoryId, status`
  - `orders.userId, createdAt`
  - `orders.status`
- **N+1 prevention:** Dùng `include` trong Prisma
- **Pagination:** Cursor-based cho danh sách lớn

## 📋 Checklist khi build feature mới

- [ ] Đọc requirement kỹ, hỏi nếu unclear
- [ ] Vẽ flow diagram (cho feature phức tạp)
- [ ] Define types/interfaces trước
- [ ] Design database schema (nếu cần)
- [ ] Implement service layer (business logic)
- [ ] Implement API endpoints với validation
- [ ] Implement UI với loading + error states
- [ ] Test happy path + edge cases
- [ ] Check accessibility
- [ ] Check mobile responsive
- [ ] Check performance (Lighthouse > 90)
- [ ] Add monitoring/logging
- [ ] Update documentation

## 🇻🇳 Đặc thù thị trường Việt Nam

- **COD chiếm 60-70%** đơn hàng → optimize flow này
- **Mobile-first:** > 80% user dùng mobile
- **Mạng xã hội:** Tích hợp share lên Facebook, Zalo
- **Live chat:** Zalo OA, Messenger là chuẩn
- **Đa cổng thanh toán:** VNPay, MoMo, ZaloPay tối thiểu
- **Hỗ trợ dấu tiếng Việt** trong search
- **Format số:** 1.000.000đ (dấu chấm), không phải 1,000,000
- **Format ngày:** DD/MM/YYYY
