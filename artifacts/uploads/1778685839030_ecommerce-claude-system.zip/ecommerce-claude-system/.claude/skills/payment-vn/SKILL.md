---
name: payment-vn
description: Use this skill when integrating Vietnamese payment gateways (VNPay, MoMo, ZaloPay) or implementing payment flows. Covers signature verification, callback handling, idempotency, refunds, and error recovery for Vietnamese e-commerce.
---

# Payment Integration Skill (Vietnam)

## 🎯 Tổng quan các cổng thanh toán VN

| Cổng | Phù hợp | Phí (~) | Độ phức tạp |
|------|---------|---------|-------------|
| **VNPay** | Phổ biến, ATM/Visa/QR | 1.1-2.5% | Trung bình |
| **MoMo** | Ví điện tử số 1 VN | 1.5-2% | Dễ |
| **ZaloPay** | Tích hợp Zalo | 1.5-2% | Dễ |
| **COD** | Bắt buộc cho VN | 0% (nhưng có rủi ro) | Đơn giản |

**Khuyến nghị:** Tích hợp tối thiểu 3: COD + VNPay + MoMo.

## 🏗️ Architecture Pattern

```
┌─────────────────────────────────────────────────────┐
│           Payment Service (Abstract)                 │
├─────────────────────────────────────────────────────┤
│  createPayment(order)  →  PaymentUrl                │
│  verifyCallback(data)  →  PaymentResult             │
│  queryStatus(txnId)    →  PaymentStatus             │
│  refund(payment, amt)  →  RefundResult              │
└─────────────────────────────────────────────────────┘
            ▲           ▲          ▲
    ┌───────┴──┐  ┌─────┴────┐  ┌──┴──────┐
    │ VNPay    │  │ MoMo     │  │ ZaloPay │
    │ Provider │  │ Provider │  │ Provider│
    └──────────┘  └──────────┘  └─────────┘
```

### Interface chung
```typescript
// lib/payment/types.ts
export interface PaymentProvider {
  name: PaymentMethod;
  createPaymentUrl(params: CreatePaymentParams): Promise<string>;
  verifyCallback(data: Record<string, string>): Promise<CallbackResult>;
  queryTransaction(txnId: string): Promise<TransactionStatus>;
  refund?(params: RefundParams): Promise<RefundResult>;
}

export interface CreatePaymentParams {
  orderId: string;
  orderNumber: string;
  amount: number; // VND, integer
  description: string;
  returnUrl: string;
  ipnUrl: string; // Webhook URL
  customerInfo?: {
    fullName: string;
    email?: string;
    phone: string;
  };
}

export interface CallbackResult {
  success: boolean;
  orderNumber: string;
  amount: number;
  transactionId: string;
  paymentTime: Date;
  rawData: Record<string, unknown>;
  errorMessage?: string;
}
```

## 💳 VNPay Implementation

### Setup
```bash
# .env
VNPAY_TMN_CODE=your_tmn_code
VNPAY_HASH_SECRET=your_hash_secret
VNPAY_URL=https://sandbox.vnpayment.vn/paymentv2/vpcpay.html # sandbox
# Production: https://vnpayment.vn/paymentv2/vpcpay.html
```

### Implementation
```typescript
// lib/payment/vnpay.ts
import crypto from 'crypto';
import { format } from 'date-fns';

export class VNPayProvider implements PaymentProvider {
  name = 'VNPAY' as const;

  private tmnCode = process.env.VNPAY_TMN_CODE!;
  private hashSecret = process.env.VNPAY_HASH_SECRET!;
  private vnpUrl = process.env.VNPAY_URL!;

  async createPaymentUrl(params: CreatePaymentParams): Promise<string> {
    const date = new Date();
    const createDate = format(date, 'yyyyMMddHHmmss');
    const expireDate = format(
      new Date(date.getTime() + 15 * 60 * 1000), // +15 min
      'yyyyMMddHHmmss'
    );

    const vnpParams: Record<string, string> = {
      vnp_Version: '2.1.0',
      vnp_Command: 'pay',
      vnp_TmnCode: this.tmnCode,
      vnp_Locale: 'vn',
      vnp_CurrCode: 'VND',
      vnp_TxnRef: params.orderNumber,
      vnp_OrderInfo: params.description,
      vnp_OrderType: 'other',
      vnp_Amount: String(params.amount * 100), // VNPay yêu cầu * 100
      vnp_ReturnUrl: params.returnUrl,
      vnp_IpAddr: '127.0.0.1', // Lấy từ request
      vnp_CreateDate: createDate,
      vnp_ExpireDate: expireDate,
    };

    // Sort keys & build query
    const sortedParams = this.sortObject(vnpParams);
    const signData = new URLSearchParams(sortedParams).toString();

    // Generate signature
    const hmac = crypto.createHmac('sha512', this.hashSecret);
    const signed = hmac.update(Buffer.from(signData, 'utf-8')).digest('hex');

    sortedParams['vnp_SecureHash'] = signed;

    return `${this.vnpUrl}?${new URLSearchParams(sortedParams).toString()}`;
  }

  async verifyCallback(data: Record<string, string>): Promise<CallbackResult> {
    const { vnp_SecureHash, ...params } = data;

    // 1. Verify signature
    const sortedParams = this.sortObject(params);
    const signData = new URLSearchParams(sortedParams).toString();
    const hmac = crypto.createHmac('sha512', this.hashSecret);
    const calculatedHash = hmac.update(Buffer.from(signData, 'utf-8')).digest('hex');

    if (calculatedHash !== vnp_SecureHash) {
      return {
        success: false,
        orderNumber: params.vnp_TxnRef,
        amount: 0,
        transactionId: '',
        paymentTime: new Date(),
        rawData: data,
        errorMessage: 'Invalid signature',
      };
    }

    // 2. Check response code
    const isSuccess = params.vnp_ResponseCode === '00' && params.vnp_TransactionStatus === '00';

    return {
      success: isSuccess,
      orderNumber: params.vnp_TxnRef,
      amount: parseInt(params.vnp_Amount) / 100,
      transactionId: params.vnp_TransactionNo,
      paymentTime: this.parseVNPayDate(params.vnp_PayDate),
      rawData: data,
      errorMessage: isSuccess ? undefined : this.getErrorMessage(params.vnp_ResponseCode),
    };
  }

  private sortObject(obj: Record<string, string>): Record<string, string> {
    return Object.keys(obj)
      .sort()
      .reduce((result, key) => {
        result[key] = obj[key];
        return result;
      }, {} as Record<string, string>);
  }

  private parseVNPayDate(dateStr: string): Date {
    // Format: yyyyMMddHHmmss
    const year = parseInt(dateStr.substr(0, 4));
    const month = parseInt(dateStr.substr(4, 2)) - 1;
    const day = parseInt(dateStr.substr(6, 2));
    const hour = parseInt(dateStr.substr(8, 2));
    const min = parseInt(dateStr.substr(10, 2));
    const sec = parseInt(dateStr.substr(12, 2));
    return new Date(year, month, day, hour, min, sec);
  }

  private getErrorMessage(code: string): string {
    const messages: Record<string, string> = {
      '01': 'Giao dịch chưa hoàn tất',
      '02': 'Giao dịch bị lỗi',
      '04': 'Giao dịch đảo (Khách đã bị trừ tiền nhưng GD không thành công)',
      '05': 'VNPAY đang xử lý GD',
      '06': 'VNPAY đã gửi yêu cầu hoàn tiền sang Ngân hàng',
      '07': 'Giao dịch nghi ngờ gian lận',
      '09': 'Giao dịch hoàn trả bị từ chối',
      '24': 'Khách hủy giao dịch',
    };
    return messages[code] || 'Giao dịch thất bại';
  }
}
```

## 📱 MoMo Implementation

```typescript
// lib/payment/momo.ts
import crypto from 'crypto';

export class MoMoProvider implements PaymentProvider {
  name = 'MOMO' as const;

  private partnerCode = process.env.MOMO_PARTNER_CODE!;
  private accessKey = process.env.MOMO_ACCESS_KEY!;
  private secretKey = process.env.MOMO_SECRET_KEY!;
  private endpoint = process.env.MOMO_ENDPOINT!;

  async createPaymentUrl(params: CreatePaymentParams): Promise<string> {
    const requestId = `${params.orderNumber}-${Date.now()}`;

    const rawSignature =
      `accessKey=${this.accessKey}` +
      `&amount=${params.amount}` +
      `&extraData=` +
      `&ipnUrl=${params.ipnUrl}` +
      `&orderId=${params.orderNumber}` +
      `&orderInfo=${params.description}` +
      `&partnerCode=${this.partnerCode}` +
      `&redirectUrl=${params.returnUrl}` +
      `&requestId=${requestId}` +
      `&requestType=captureWallet`;

    const signature = crypto
      .createHmac('sha256', this.secretKey)
      .update(rawSignature)
      .digest('hex');

    const requestBody = {
      partnerCode: this.partnerCode,
      partnerName: 'Test',
      storeId: 'MomoTestStore',
      requestId,
      amount: params.amount,
      orderId: params.orderNumber,
      orderInfo: params.description,
      redirectUrl: params.returnUrl,
      ipnUrl: params.ipnUrl,
      lang: 'vi',
      extraData: '',
      requestType: 'captureWallet',
      signature,
    };

    const response = await fetch(`${this.endpoint}/v2/gateway/api/create`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(requestBody),
    });

    const data = await response.json();

    if (data.resultCode !== 0) {
      throw new Error(`MoMo error: ${data.message}`);
    }

    return data.payUrl;
  }

  async verifyCallback(data: Record<string, string>): Promise<CallbackResult> {
    const rawSignature =
      `accessKey=${this.accessKey}` +
      `&amount=${data.amount}` +
      `&extraData=${data.extraData}` +
      `&message=${data.message}` +
      `&orderId=${data.orderId}` +
      `&orderInfo=${data.orderInfo}` +
      `&orderType=${data.orderType}` +
      `&partnerCode=${data.partnerCode}` +
      `&payType=${data.payType}` +
      `&requestId=${data.requestId}` +
      `&responseTime=${data.responseTime}` +
      `&resultCode=${data.resultCode}` +
      `&transId=${data.transId}`;

    const signature = crypto
      .createHmac('sha256', this.secretKey)
      .update(rawSignature)
      .digest('hex');

    const isValid = signature === data.signature;
    const isSuccess = isValid && data.resultCode === '0';

    return {
      success: isSuccess,
      orderNumber: data.orderId,
      amount: parseInt(data.amount),
      transactionId: data.transId,
      paymentTime: new Date(parseInt(data.responseTime)),
      rawData: data,
      errorMessage: isSuccess ? undefined : data.message,
    };
  }
}
```

## 🔄 Payment Flow - Complete

### 1. Initiate Payment (Frontend → Backend)
```typescript
// app/api/payments/create/route.ts
export async function POST(request: NextRequest) {
  const session = await auth();
  if (!session) throw errors.UNAUTHORIZED();

  const { orderId } = z.object({ orderId: z.string().cuid() }).parse(await request.json());

  // 1. Lock order trong transaction
  const order = await prisma.$transaction(async (tx) => {
    const order = await tx.order.findUnique({
      where: { id: orderId, userId: session.user.id },
    });

    if (!order) throw errors.NOT_FOUND('Đơn hàng');
    if (order.paymentStatus === 'PAID') throw errors.CONFLICT('Đã thanh toán');
    if (order.status === 'CANCELLED') throw errors.CONFLICT('Đơn đã hủy');

    return order;
  });

  // 2. Get provider
  const provider = getPaymentProvider(order.paymentMethod);

  // 3. Create payment URL
  const paymentUrl = await provider.createPaymentUrl({
    orderId: order.id,
    orderNumber: order.orderNumber,
    amount: order.total,
    description: `Thanh toan don hang ${order.orderNumber}`,
    returnUrl: `${process.env.NEXT_PUBLIC_APP_URL}/orders/${order.orderNumber}/result`,
    ipnUrl: `${process.env.NEXT_PUBLIC_APP_URL}/api/webhooks/${provider.name.toLowerCase()}`,
    customerInfo: {
      fullName: order.recipientName,
      phone: order.recipientPhone,
    },
  });

  // 4. Log payment attempt
  await prisma.payment.create({
    data: {
      orderId: order.id,
      method: order.paymentMethod,
      amount: order.total,
      status: 'PENDING',
    },
  });

  return NextResponse.json({ data: { paymentUrl } });
}
```

### 2. Webhook Handler (CRITICAL)
```typescript
// app/api/webhooks/vnpay/route.ts
export async function POST(request: NextRequest) {
  try {
    const data = Object.fromEntries(new URL(request.url).searchParams);

    const provider = new VNPayProvider();
    const result = await provider.verifyCallback(data);

    // 1. Tìm payment - LUÔN check tồn tại
    const payment = await prisma.payment.findFirst({
      where: {
        order: { orderNumber: result.orderNumber },
        method: 'VNPAY',
      },
      include: { order: true },
    });

    if (!payment) {
      // Log nhưng vẫn trả OK để VNPay không retry vô tận
      console.error('Payment not found', result);
      return NextResponse.json({ RspCode: '01', Message: 'Order not found' });
    }

    // 2. Check idempotency - đã xử lý rồi thì thôi
    if (payment.status === 'PAID') {
      return NextResponse.json({ RspCode: '02', Message: 'Already confirmed' });
    }

    // 3. Verify amount match
    if (payment.amount !== BigInt(result.amount)) {
      console.error('Amount mismatch', { expected: payment.amount, got: result.amount });
      return NextResponse.json({ RspCode: '04', Message: 'Amount invalid' });
    }

    // 4. Update trong transaction
    await prisma.$transaction(async (tx) => {
      // Update payment
      await tx.payment.update({
        where: { id: payment.id },
        data: {
          status: result.success ? 'PAID' : 'FAILED',
          gatewayTransactionId: result.transactionId,
          gatewayResponse: result.rawData as any,
          paidAt: result.success ? result.paymentTime : null,
        },
      });

      // Update order nếu success
      if (result.success) {
        await tx.order.update({
          where: { id: payment.orderId },
          data: {
            paymentStatus: 'PAID',
            status: 'CONFIRMED',
          },
        });

        // Trigger events
        await sendOrderConfirmationEmail(payment.order);
        await createShippingOrder(payment.order);
      }
    });

    // 5. Return success theo format VNPay
    return NextResponse.json({ RspCode: '00', Message: 'Confirm Success' });
  } catch (error) {
    console.error('VNPay webhook error', error);
    Sentry.captureException(error);
    return NextResponse.json({ RspCode: '99', Message: 'Unknown error' });
  }
}
```

### 3. Return URL Handler (Frontend redirect)
```typescript
// app/orders/[orderNumber]/result/page.tsx
export default async function PaymentResultPage({ params, searchParams }: Props) {
  // KHÔNG TRUST query params - LUÔN query DB
  const order = await prisma.order.findUnique({
    where: { orderNumber: params.orderNumber },
    include: { payments: { orderBy: { createdAt: 'desc' }, take: 1 } },
  });

  if (!order) notFound();

  // Hiển thị status từ DB (đã được webhook update)
  const latestPayment = order.payments[0];
  const isPaid = order.paymentStatus === 'PAID';

  // Nếu chưa có status (webhook chậm), poll hoặc show "đang xử lý"
  if (latestPayment?.status === 'PENDING') {
    return <PaymentPendingPage order={order} />;
  }

  return isPaid ? <PaymentSuccessPage order={order} /> : <PaymentFailedPage order={order} />;
}
```

## ⚠️ Critical Rules - Bảo mật & Reliability

### LUÔN làm
- ✅ **Verify signature** mọi callback - đừng bao giờ tin client/gateway data
- ✅ **Verify amount** match với order trong DB
- ✅ **Idempotency** - dùng `gatewayTransactionId` làm unique key
- ✅ **Transaction** khi update payment + order
- ✅ **Log everything** - lưu raw response để audit/debug
- ✅ **Update từ webhook**, không phải từ return URL
- ✅ **Set timeout** (15 phút) cho payment, auto-cancel nếu hết hạn
- ✅ **Test sandbox** kỹ trước khi go-live

### KHÔNG BAO GIỜ làm
- ❌ Trust giá trị từ return URL để confirm payment
- ❌ Confirm order trước khi nhận webhook success
- ❌ Lưu thông tin thẻ tín dụng (PCI DSS compliance)
- ❌ Expose secret keys ở frontend
- ❌ Skip signature verification "vì tin gateway"
- ❌ Process webhook mà không check existing status
- ❌ Hiển thị raw error message từ gateway cho user

## 🔄 Refund Flow

```typescript
async function refundPayment(paymentId: string, amount: number, reason: string) {
  const payment = await prisma.payment.findUnique({
    where: { id: paymentId },
    include: { order: true },
  });

  if (!payment) throw errors.NOT_FOUND('Payment');
  if (payment.status !== 'PAID') throw errors.CONFLICT('Chỉ refund được payment đã thanh toán');
  if (amount > Number(payment.amount)) throw errors.VALIDATION('Số tiền refund vượt quá');

  const provider = getPaymentProvider(payment.method);

  if (!provider.refund) {
    throw errors.CONFLICT('Cổng thanh toán không hỗ trợ refund tự động, cần xử lý manual');
  }

  const result = await provider.refund({
    transactionId: payment.gatewayTransactionId!,
    amount,
    reason,
  });

  await prisma.$transaction(async (tx) => {
    // Tạo refund record
    await tx.refund.create({
      data: {
        paymentId,
        amount,
        reason,
        status: result.success ? 'COMPLETED' : 'FAILED',
        gatewayResponse: result.rawData as any,
      },
    });

    // Update payment status
    if (result.success) {
      const totalRefunded = /* sum of refunds */;
      await tx.payment.update({
        where: { id: paymentId },
        data: {
          status: totalRefunded >= Number(payment.amount) ? 'REFUNDED' : 'PARTIAL_REFUNDED',
        },
      });
    }
  });
}
```

## 🧪 Testing Strategy

### Sandbox credentials
- VNPay: https://sandbox.vnpayment.vn/apis/vnpay-demo/
- MoMo: https://developers.momo.vn/v3/docs/payment/onetime
- ZaloPay: https://docs.zalopay.vn/

### Test cases bắt buộc
- ✅ Payment success - status update đúng
- ✅ Payment failed - không update order
- ✅ User cancel - timeout + cancel order
- ✅ Webhook called twice - idempotent (chỉ xử lý 1 lần)
- ✅ Wrong signature - reject
- ✅ Amount mismatch - reject
- ✅ Order không tồn tại - graceful error
- ✅ Order đã paid - không double-charge
- ✅ Network failure khi gọi gateway - retry / show error

## ✅ Pre-Launch Checklist

- [ ] Đã đổi từ sandbox sang production credentials
- [ ] HTTPS bắt buộc cho mọi callback URL
- [ ] Domain whitelist trên gateway dashboard
- [ ] Webhook URL public, không có auth
- [ ] Logging đầy đủ (request, response, errors)
- [ ] Sentry/monitoring alerts cho payment errors
- [ ] Tested các edge cases trên
- [ ] Có quy trình manual refund cho support team
- [ ] Database backup trước go-live
