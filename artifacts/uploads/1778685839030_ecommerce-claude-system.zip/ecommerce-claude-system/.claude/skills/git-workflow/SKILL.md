---
name: git-workflow
description: Quy ước Git workflow, branch naming, conventional commits, PR template và code review checklist cho dự án e-commerce. Dùng skill này khi làm việc với version control, tạo commit, mở Pull Request.
---

# Git Workflow Skill

## 1. Branching Strategy

Dự án sử dụng **Trunk-Based Development** với short-lived feature branches.

```
main (protected, production)
  └── develop (staging, integration)
       ├── feature/product-search
       ├── feature/checkout-vnpay
       ├── fix/cart-quantity-bug
       └── chore/update-deps
```

### Branch naming convention

| Prefix | Khi nào dùng | Ví dụ |
|--------|--------------|-------|
| `feature/` | Tính năng mới | `feature/wishlist`, `feature/product-reviews` |
| `fix/` | Bug fix | `fix/cart-total-calculation` |
| `hotfix/` | Fix khẩn cấp trên production | `hotfix/payment-timeout` |
| `chore/` | Maintenance, deps, config | `chore/upgrade-nextjs-15` |
| `refactor/` | Refactor không thay đổi behavior | `refactor/extract-payment-service` |
| `docs/` | Cập nhật docs | `docs/api-payment-flow` |
| `test/` | Thêm/sửa tests | `test/checkout-e2e` |
| `perf/` | Performance improvements | `perf/optimize-product-list-query` |

**Quy tắc:**
- Tên branch dùng kebab-case (gạch ngang)
- Ngắn gọn, mô tả rõ mục đích (3-5 từ)
- Không dùng tiếng Việt có dấu trong tên branch
- Một branch = một mục đích duy nhất
- Branch sống ngắn (< 3 ngày, lý tưởng < 1 ngày)

## 2. Conventional Commits

Tất cả commit message **bắt buộc** theo format [Conventional Commits](https://www.conventionalcommits.org/).

```
<type>(<scope>): <subject>

<body>

<footer>
```

### Types

| Type | Mô tả | Trigger version bump |
|------|-------|---------------------|
| `feat` | Tính năng mới | MINOR |
| `fix` | Bug fix | PATCH |
| `docs` | Chỉ thay đổi docs | - |
| `style` | Format code, không đổi logic | - |
| `refactor` | Refactor không đổi behavior | - |
| `perf` | Performance improvement | PATCH |
| `test` | Thêm/sửa tests | - |
| `chore` | Maintenance, deps | - |
| `build` | Build system, deps | - |
| `ci` | CI/CD config | - |
| `revert` | Revert commit trước | - |

### Scopes (cho dự án này)

`auth`, `cart`, `checkout`, `payment`, `product`, `order`, `user`, `admin`, `seo`, `db`, `api`, `ui`, `email`, `search`, `review`, `voucher`, `shipping`, `inventory`, `deps`

### Ví dụ commit messages

✅ **Đúng:**
```
feat(checkout): add VNPay payment integration

Implement VNPay redirect flow with HMAC SHA512 signature
verification and proper error code mapping.

Closes #123
```

```
fix(cart): correct total calculation when applying voucher

The voucher discount was applied before tax calculation,
causing incorrect totals. Now applied after subtotal.

Fixes #145
```

```
perf(product): add database index on category_id and slug

Reduces product list query from 450ms to 80ms on staging.
```

```
chore(deps): bump next from 14.2.0 to 14.2.5
```

❌ **Sai:**
```
update code           # Quá mơ hồ
fix bug               # Không nói rõ bug gì
WIP                   # Không bao giờ commit WIP vào shared branch
sửa lỗi giỏ hàng      # Tiếng Việt có dấu, không có type
Fixed cart bug.       # Không có scope, không theo convention
```

### Commit message rules

- **Subject line ≤ 72 ký tự**
- **Imperative mood**: "add" không phải "added" hay "adds"
- **Không dấu chấm cuối** subject line
- **Body**: giải thích **why** (tại sao) không phải **what** (cái gì)
- **Footer**: link issue/ticket (`Closes #123`, `Fixes #456`, `Refs #789`)
- **Breaking changes**: thêm `!` sau type và `BREAKING CHANGE:` trong footer

```
feat(api)!: change order status response format

BREAKING CHANGE: Order status is now returned as an object
{ code, label, color } instead of plain string.
Migration guide: /docs/migrations/order-status-v2.md
```

## 3. Pull Request Workflow

### Trước khi mở PR

```bash
# 1. Cập nhật develop
git checkout develop
git pull origin develop

# 2. Rebase branch của bạn lên develop
git checkout feature/your-feature
git rebase develop

# 3. Chạy đầy đủ kiểm tra local
pnpm lint
pnpm type-check
pnpm test
pnpm build

# 4. Push (dùng --force-with-lease nếu đã rebase)
git push origin feature/your-feature --force-with-lease
```

### PR Template

Đặt tại `.github/pull_request_template.md`:

```markdown
## 📝 Mô tả

<!-- Mô tả ngắn gọn thay đổi này làm gì -->

## 🎯 Loại thay đổi

- [ ] 🐛 Bug fix (non-breaking change sửa lỗi)
- [ ] ✨ Feature mới (non-breaking change thêm chức năng)
- [ ] 💥 Breaking change (thay đổi không tương thích ngược)
- [ ] 📝 Cập nhật docs
- [ ] ♻️ Refactor (không đổi behavior)
- [ ] ⚡ Performance improvement
- [ ] 🧪 Tests

## 🔗 Issue liên quan

Closes #

## 📸 Screenshots / Videos

<!-- Nếu thay đổi UI, thêm before/after screenshots -->

## ✅ Checklist

- [ ] Code tuân thủ style guide của dự án
- [ ] Đã self-review code
- [ ] Đã thêm comments cho đoạn code phức tạp
- [ ] Đã cập nhật documentation tương ứng
- [ ] Không có warning mới khi build
- [ ] Đã thêm tests cho code mới
- [ ] Tất cả tests pass (unit + integration + E2E)
- [ ] Đã test trên mobile viewport
- [ ] Không expose secrets/API keys
- [ ] Đã cân nhắc performance impact
- [ ] Database migration (nếu có) là backwards-compatible

## 🧪 Cách test

<!-- Hướng dẫn reviewer cách test thay đổi này -->

1. ...
2. ...

## 📊 Performance Impact

<!-- Nếu có ảnh hưởng performance, ghi rõ -->

- Bundle size change: 
- DB query impact: 
- LCP/INP impact: 

## 🔐 Security Considerations

<!-- Có ảnh hưởng đến auth, payment, PII, permissions không? -->

## 📝 Notes cho reviewer

<!-- Bất cứ điều gì reviewer cần biết -->
```

### PR Title

Cùng format với commit: `feat(checkout): add VNPay payment integration`

### PR Size

- **Lý tưởng**: < 400 dòng diff
- **Chấp nhận được**: 400-800 dòng
- **Cần chia nhỏ**: > 800 dòng

PR nhỏ → review nhanh → merge sớm → ít conflict.

## 4. Code Review Checklist

### Người review (Reviewer)

**Functionality**
- [ ] Code làm đúng những gì PR description nói
- [ ] Edge cases đã được xử lý (empty, null, max values)
- [ ] Error handling đầy đủ và meaningful
- [ ] Không có hardcoded values (dùng env vars / constants)

**Security**
- [ ] Input validation với Zod ở mọi entry point
- [ ] Không SQL injection (dùng Prisma parameterized queries)
- [ ] Không XSS (escape user content, dùng DOMPurify)
- [ ] Authorization check ở mọi protected route
- [ ] Không log PII (password, token, card number)
- [ ] Secrets không bị commit vào code

**Performance**
- [ ] Không N+1 query (dùng `include` / `select` đúng cách)
- [ ] Pagination cho list endpoints
- [ ] Cache headers cho static content
- [ ] Image optimization (next/image, lazy load)
- [ ] Bundle size không tăng đột biến

**Code Quality**
- [ ] Naming rõ ràng, self-explanatory
- [ ] Functions ngắn (< 50 dòng), single responsibility
- [ ] Không duplicate code (DRY)
- [ ] TypeScript strict, không dùng `any`
- [ ] Comments giải thích "why" không phải "what"

**Testing**
- [ ] Unit tests cho business logic
- [ ] Integration tests cho API endpoints
- [ ] E2E test cho critical flow (checkout, auth)
- [ ] Tests có ý nghĩa, không chỉ để cover lines

**UI/UX (nếu có)**
- [ ] Responsive trên mobile (375px), tablet (768px), desktop (1280px)
- [ ] Loading states
- [ ] Error states
- [ ] Empty states
- [ ] Accessibility (keyboard nav, ARIA labels, contrast)
- [ ] Vietnamese text hiển thị đúng (font, dấu)

**Database (nếu có migration)**
- [ ] Migration backwards-compatible
- [ ] Đã có rollback plan
- [ ] Index cho queries thường dùng
- [ ] Không lock table lâu trên prod

### Người tạo PR (Author)

- [ ] Đã self-review trước khi request review
- [ ] PR description rõ ràng, có context
- [ ] Đã test thủ công trên local
- [ ] Đã chạy full CI local trước khi push
- [ ] Phản hồi comments trong 24h
- [ ] Resolve conflicts kịp thời

### Comment etiquette

- ✅ "What about the case when X is null?" (hỏi)
- ✅ "Suggestion: extract this into a helper function for reusability" (gợi ý có lý do)
- ✅ "nit: typo in variable name" (đánh dấu nit là issue nhỏ)
- ❌ "This is bad" (không constructive)
- ❌ "Why did you do this?" (gây áp lực)

**Mức độ comment:**
- `nit:` — nhỏ, không block merge (typo, formatting)
- `suggestion:` — gợi ý cải thiện, không bắt buộc
- `question:` — cần author giải thích
- `issue:` — phải fix trước khi merge
- `blocker:` — security/correctness, MUST fix

## 5. Merge Strategy

### Develop branch
- **Squash and merge** (mặc định)
- Commit message cuối cùng theo Conventional Commits
- Giữ lịch sử develop sạch, mỗi PR = 1 commit

### Main branch
- **Merge commit** từ develop → main (release)
- Tag version theo SemVer: `v1.2.3`
- Tạo GitHub Release với changelog

### Hotfix flow
```
main → hotfix/critical-bug → main (fast merge)
                          → develop (sync back)
```

## 6. .gitignore

```gitignore
# Dependencies
node_modules/
.pnp
.pnp.js
.yarn/install-state.gz

# Testing
coverage/
.nyc_output/
playwright-report/
test-results/
playwright/.cache/

# Next.js
.next/
out/
build/
dist/

# Production
*.tsbuildinfo
next-env.d.ts

# Environment
.env
.env*.local
.env.development
.env.production
.env.staging
!.env.example

# Vercel
.vercel

# Database
*.db
*.sqlite
prisma/migrations/dev/

# Logs
*.log
npm-debug.log*
yarn-debug.log*
yarn-error.log*
pnpm-debug.log*

# IDE
.vscode/*
!.vscode/settings.json
!.vscode/extensions.json
!.vscode/launch.json
.idea/
*.swp
*.swo
*~

# OS
.DS_Store
Thumbs.db
desktop.ini

# Uploads (local dev)
public/uploads/
public/temp/

# Cache
.eslintcache
.stylelintcache
.turbo/
.cache/

# Misc
*.pem
.history/

# Sentry
.sentryclirc

# Bundle analyzer
.next/analyze/
```

## 7. Git Hooks (Husky + lint-staged)

```bash
pnpm add -D husky lint-staged
pnpm dlx husky init
```

`.husky/pre-commit`:
```bash
#!/usr/bin/env sh
. "$(dirname -- "$0")/_/husky.sh"

pnpm lint-staged
```

`.husky/commit-msg`:
```bash
#!/usr/bin/env sh
. "$(dirname -- "$0")/_/husky.sh"

pnpm dlx commitlint --edit "$1"
```

`package.json`:
```json
{
  "lint-staged": {
    "*.{ts,tsx}": [
      "eslint --fix",
      "prettier --write"
    ],
    "*.{json,md,css}": [
      "prettier --write"
    ]
  }
}
```

`commitlint.config.js`:
```javascript
module.exports = {
  extends: ['@commitlint/config-conventional'],
  rules: {
    'type-enum': [
      2,
      'always',
      ['feat', 'fix', 'docs', 'style', 'refactor', 'perf', 'test', 'chore', 'build', 'ci', 'revert'],
    ],
    'subject-case': [2, 'never', ['upper-case', 'pascal-case', 'start-case']],
    'header-max-length': [2, 'always', 72],
  },
};
```

## 8. Protecting Branches (GitHub settings)

**main branch:**
- ✅ Require PR before merging
- ✅ Require approvals: 1 (small team) hoặc 2 (lớn hơn)
- ✅ Dismiss stale approvals when new commits pushed
- ✅ Require status checks: CI, tests, type-check, lint
- ✅ Require branches up to date before merging
- ✅ Require conversation resolution
- ✅ Do not allow bypassing
- ❌ Block force push
- ❌ Block deletion

**develop branch:**
- Tương tự nhưng có thể chỉ cần 1 approval

## 9. Common Workflows

### Bắt đầu feature mới
```bash
git checkout develop
git pull
git checkout -b feature/wishlist
# work, commit theo Conventional Commits
git push -u origin feature/wishlist
# Mở PR vào develop trên GitHub
```

### Cập nhật branch khi develop có thay đổi
```bash
git checkout develop
git pull
git checkout feature/wishlist
git rebase develop
# Resolve conflicts nếu có
git push --force-with-lease
```

### Sửa commit message gần nhất (chưa push)
```bash
git commit --amend
```

### Squash các commit trước khi mở PR
```bash
git rebase -i develop
# Đổi pick thành squash/fixup cho commits cần gộp
```

### Cherry-pick fix từ branch khác
```bash
git cherry-pick <commit-hash>
```

### Rollback commit đã merged
```bash
git revert <commit-hash>
git push
```

### Hủy thay đổi local chưa commit
```bash
git restore .              # File đã modified
git restore --staged .     # Unstage
git clean -fd              # Xóa file untracked
```

## 10. Release Process

```bash
# 1. Trên develop, chạy đầy đủ tests
pnpm ci

# 2. Bump version
pnpm version patch  # hoặc minor / major

# 3. Generate changelog
pnpm dlx conventional-changelog -p angular -i CHANGELOG.md -s

# 4. Commit và tag
git add CHANGELOG.md package.json
git commit -m "chore(release): v1.2.3"
git tag v1.2.3

# 5. Push
git push origin develop --tags

# 6. Mở PR develop → main
# 7. Sau khi merged, GitHub Action auto deploy production
# 8. Tạo GitHub Release với changelog
```

## 11. Anti-Patterns — KHÔNG làm

- ❌ Commit trực tiếp vào `main` hoặc `develop`
- ❌ Force push vào shared branches
- ❌ Commit `node_modules`, `.env`, build artifacts
- ❌ Commit secrets (API keys, passwords, tokens)
- ❌ PR khổng lồ (> 1000 dòng) — chia nhỏ ra
- ❌ Merge khi CI đỏ
- ❌ Merge khi có unresolved conversations
- ❌ Commit message kiểu "fix" / "update" / "asdf"
- ❌ Branch sống quá lâu (> 1 tuần)
- ❌ Mix nhiều thay đổi không liên quan trong 1 PR

## 12. Quick Reference

```bash
# Kiểm tra trạng thái
git status
git log --oneline -10
git diff
git diff --staged

# Stash thay đổi tạm
git stash
git stash pop
git stash list

# Xem ai sửa dòng nào
git blame path/to/file.ts

# Tìm commit theo nội dung
git log --grep="VNPay"
git log -S "function payment"  # Tìm theo code

# So sánh branches
git diff develop..feature/wishlist

# Reset (cẩn thận!)
git reset --soft HEAD~1   # Giữ thay đổi
git reset --hard HEAD~1   # Mất thay đổi
```
