---
name: deployment
description: Use this skill when deploying the e-commerce app, setting up CI/CD pipelines, configuring environments, or troubleshooting production issues. Covers Vercel, Railway, GitHub Actions, monitoring, and Vietnamese hosting considerations.
---

# Deployment Skill

## 🚀 Deployment Architecture

### Recommended Stack
```
┌─────────────────────────────────────────┐
│  Frontend (Next.js)                      │
│  → Vercel (auto-deploy from Git)         │
├─────────────────────────────────────────┤
│  Database (PostgreSQL)                   │
│  → Supabase / Railway / Neon             │
├─────────────────────────────────────────┤
│  Cache + Queue                           │
│  → Upstash Redis (serverless)            │
├─────────────────────────────────────────┤
│  File Storage                            │
│  → Cloudinary / AWS S3                   │
├─────────────────────────────────────────┤
│  Email                                   │
│  → Resend / SendGrid                     │
├─────────────────────────────────────────┤
│  Monitoring                              │
│  → Sentry + Vercel Analytics             │
└─────────────────────────────────────────┘
```

### Cost estimate (small-medium scale)
- Vercel Pro: $20/mo
- Supabase Pro: $25/mo
- Upstash: ~$10/mo
- Cloudinary: Free tier đủ start
- **Tổng:** ~$60-100/mo cho 100k traffic/tháng

## 📦 Environments

### 3-tier setup
```
┌─────────────┐    ┌─────────────┐    ┌─────────────┐
│ Development │ →  │   Staging   │ →  │ Production  │
└─────────────┘    └─────────────┘    └─────────────┘
   localhost      staging.shop.vn      shop.vn
   .env.local     .env.staging         .env.production
```

### Environment variables checklist
```bash
# === REQUIRED ===
DATABASE_URL=postgresql://...
DIRECT_URL=postgresql://... # For migrations

NEXTAUTH_URL=https://yourstore.vn
NEXTAUTH_SECRET=<generated>

# === Payment Gateways ===
VNPAY_TMN_CODE=
VNPAY_HASH_SECRET=
VNPAY_URL=https://vnpayment.vn/paymentv2/vpcpay.html # Production
MOMO_PARTNER_CODE=
MOMO_ACCESS_KEY=
MOMO_SECRET_KEY=
MOMO_ENDPOINT=https://payment.momo.vn # Production

# === Storage ===
CLOUDINARY_URL=
NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME=

# === Email ===
RESEND_API_KEY=
EMAIL_FROM=noreply@yourstore.vn

# === Cache & Queue ===
UPSTASH_REDIS_REST_URL=
UPSTASH_REDIS_REST_TOKEN=

# === Monitoring ===
SENTRY_DSN=
SENTRY_AUTH_TOKEN=
SENTRY_ORG=
SENTRY_PROJECT=

# === Analytics ===
NEXT_PUBLIC_GA_ID=G-XXXXXXX
NEXT_PUBLIC_FB_PIXEL_ID=

# === Shipping ===
GHN_TOKEN=
GHN_SHOP_ID=
GHTK_TOKEN=

# === Public ===
NEXT_PUBLIC_APP_URL=https://yourstore.vn
NEXT_PUBLIC_SITE_NAME=Yourstore
```

## 🏗️ Build Configuration

### next.config.js
```typescript
/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,

  images: {
    remotePatterns: [
      { protocol: 'https', hostname: 'res.cloudinary.com' },
      { protocol: 'https', hostname: 'images.unsplash.com' },
    ],
    formats: ['image/webp', 'image/avif'],
    minimumCacheTTL: 60 * 60 * 24 * 7, // 1 week
  },

  experimental: {
    serverActions: { bodySizeLimit: '2mb' },
  },

  async headers() {
    return [
      // Static assets - cache aggressive
      {
        source: '/_next/static/:path*',
        headers: [
          { key: 'Cache-Control', value: 'public, max-age=31536000, immutable' },
        ],
      },
      // Security headers (xem skill security)
      {
        source: '/(.*)',
        headers: securityHeaders,
      },
    ];
  },

  async redirects() {
    return [
      // Old URLs → new URLs
      { source: '/product/:slug', destination: '/san-pham/:slug', permanent: true },
    ];
  },

  async rewrites() {
    return [
      // SEO-friendly URLs
      { source: '/danh-muc/:slug', destination: '/category/:slug' },
    ];
  },

  // Webpack optimization
  webpack: (config) => {
    config.optimization.minimize = true;
    return config;
  },

  // Disable telemetry
  telemetry: false,
};

module.exports = nextConfig;
```

## 🔄 CI/CD - GitHub Actions

### `.github/workflows/ci.yml`
```yaml
name: CI

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main, develop]

jobs:
  lint-and-type-check:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: pnpm/action-setup@v3
        with: { version: 9 }
      - uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: 'pnpm'

      - run: pnpm install --frozen-lockfile
      - run: pnpm prisma generate
      - run: pnpm lint
      - run: pnpm typecheck

  test:
    runs-on: ubuntu-latest
    services:
      postgres:
        image: postgres:16
        env:
          POSTGRES_PASSWORD: postgres
          POSTGRES_DB: test
        ports: ['5432:5432']
        options: >-
          --health-cmd pg_isready
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5

      redis:
        image: redis:7
        ports: ['6379:6379']

    steps:
      - uses: actions/checkout@v4
      - uses: pnpm/action-setup@v3
        with: { version: 9 }
      - uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: 'pnpm'

      - run: pnpm install --frozen-lockfile
      - run: pnpm prisma generate
      - run: pnpm prisma db push
        env:
          DATABASE_URL: postgresql://postgres:postgres@localhost:5432/test

      - run: pnpm test:coverage
        env:
          DATABASE_URL: postgresql://postgres:postgres@localhost:5432/test
          REDIS_URL: redis://localhost:6379

      - uses: codecov/codecov-action@v4
        with:
          token: ${{ secrets.CODECOV_TOKEN }}

  e2e:
    runs-on: ubuntu-latest
    timeout-minutes: 60
    steps:
      - uses: actions/checkout@v4
      - uses: pnpm/action-setup@v3
        with: { version: 9 }
      - uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: 'pnpm'

      - run: pnpm install --frozen-lockfile
      - run: pnpm exec playwright install --with-deps chromium
      - run: pnpm build
      - run: pnpm test:e2e

      - uses: actions/upload-artifact@v4
        if: always()
        with:
          name: playwright-report
          path: playwright-report/

  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: pnpm/action-setup@v3
        with: { version: 9 }
      - uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: 'pnpm'

      - run: pnpm install --frozen-lockfile
      - run: pnpm build
        env:
          # Use dummy values for build
          DATABASE_URL: postgresql://dummy
          NEXTAUTH_SECRET: dummy
```

### `.github/workflows/deploy-production.yml`
```yaml
name: Deploy Production

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      # 1. Run migrations FIRST
      - uses: pnpm/action-setup@v3
        with: { version: 9 }
      - uses: actions/setup-node@v4
        with: { node-version: 20, cache: 'pnpm' }

      - run: pnpm install --frozen-lockfile
      - run: pnpm prisma migrate deploy
        env:
          DATABASE_URL: ${{ secrets.PRODUCTION_DATABASE_URL }}

      # 2. Then deploy to Vercel
      - uses: amondnet/vercel-action@v25
        with:
          vercel-token: ${{ secrets.VERCEL_TOKEN }}
          vercel-org-id: ${{ secrets.VERCEL_ORG_ID }}
          vercel-project-id: ${{ secrets.VERCEL_PROJECT_ID }}
          vercel-args: '--prod'

      # 3. Notify
      - name: Notify Slack
        uses: 8398a7/action-slack@v3
        if: always()
        with:
          status: ${{ job.status }}
          webhook_url: ${{ secrets.SLACK_WEBHOOK }}
```

## 🗃️ Database Migration in Production

### Strategy: Blue-Green Migrations

```typescript
// LUÔN backwards-compatible migrations
// Never break running application

// ❌ BAD: Drop column trong cùng deploy với code remove field
// ✅ GOOD: 2-step process

// Step 1 (Deploy A): Code stops using column, but column remains
// Step 2 (Deploy B): Migration drops column

// Renaming column - 3 steps
// Step 1: Add new column, write to both
// Step 2: Backfill data, read from new
// Step 3: Drop old column
```

### Migration Process
```bash
# Local development
pnpm prisma migrate dev --name add_voucher

# Staging
DATABASE_URL=$STAGING_URL pnpm prisma migrate deploy

# Production (via CI/CD)
DATABASE_URL=$PROD_URL pnpm prisma migrate deploy

# Rollback (rare, requires planning)
# Manually create reverse migration
```

### Backup before migration
```bash
# Supabase
supabase db dump -f backup-$(date +%Y%m%d).sql

# Self-hosted
pg_dump $DATABASE_URL > backup-$(date +%Y%m%d-%H%M%S).sql

# Restore
psql $DATABASE_URL < backup.sql
```

## 📊 Monitoring & Observability

### Sentry Setup
```typescript
// sentry.client.config.ts
import * as Sentry from '@sentry/nextjs';

Sentry.init({
  dsn: process.env.NEXT_PUBLIC_SENTRY_DSN,
  environment: process.env.NEXT_PUBLIC_ENV,

  tracesSampleRate: 0.1, // 10% performance traces
  replaysSessionSampleRate: 0.01, // 1% session replays
  replaysOnErrorSampleRate: 1.0, // 100% on error

  ignoreErrors: [
    // Browser extensions
    'top.GLOBALS',
    // Random network errors
    'NetworkError when attempting to fetch',
    // Common ad-block errors
    'Failed to fetch',
  ],

  beforeSend(event) {
    // Don't send PII
    if (event.user?.email) delete event.user.email;
    return event;
  },
});

// sentry.server.config.ts
import * as Sentry from '@sentry/nextjs';

Sentry.init({
  dsn: process.env.SENTRY_DSN,
  environment: process.env.NODE_ENV,
  tracesSampleRate: 0.1,
});
```

### Custom logging
```typescript
// lib/logger.ts
import pino from 'pino';

export const logger = pino({
  level: process.env.LOG_LEVEL || 'info',
  transport: process.env.NODE_ENV === 'development' ? {
    target: 'pino-pretty',
    options: { colorize: true },
  } : undefined,
  redact: {
    paths: [
      'password',
      'token',
      'secret',
      'authorization',
      '*.password',
      'card.number',
      'card.cvv',
    ],
    censor: '***REDACTED***',
  },
});

// Audit log cho admin actions
export const auditLogger = {
  log: async (action: string, userId: string, details: any) => {
    await prisma.auditLog.create({
      data: { action, userId, details, ip: getCurrentIp() },
    });

    logger.info({ action, userId, details }, 'Audit log');
  },
};
```

### Health Check Endpoint
```typescript
// app/api/health/route.ts
export async function GET() {
  const checks = {
    server: 'ok',
    database: 'unknown',
    redis: 'unknown',
    timestamp: new Date().toISOString(),
  };

  try {
    await prisma.$queryRaw`SELECT 1`;
    checks.database = 'ok';
  } catch {
    checks.database = 'error';
  }

  try {
    await redis.ping();
    checks.redis = 'ok';
  } catch {
    checks.redis = 'error';
  }

  const isHealthy = Object.values(checks).every(v => v === 'ok' || typeof v === 'string');

  return NextResponse.json(checks, {
    status: isHealthy ? 200 : 503,
  });
}
```

### Uptime Monitoring
- **UptimeRobot** (free tier) - ping `/api/health` mỗi 5 phút
- **Better Stack** - more advanced, có on-call
- **Vercel monitoring** - built-in cho Vercel deployments

### Alerts
Setup alerts trên Sentry/Slack cho:
- ❗ Error rate > 1%
- ❗ Payment failures
- ❗ Database connection errors
- ❗ Queue backlog > 100
- ❗ Response time p95 > 2s
- ❗ 5xx errors

## 🔄 Caching Strategy

### Vercel Edge Cache + ISR
```typescript
// app/(shop)/san-pham/[slug]/page.tsx
export const revalidate = 3600; // Revalidate mỗi giờ

export async function generateStaticParams() {
  // Pre-build top products
  const products = await prisma.product.findMany({
    where: { status: 'PUBLISHED' },
    orderBy: { soldCount: 'desc' },
    take: 100,
    select: { slug: true },
  });
  return products.map(p => ({ slug: p.slug }));
}
```

### On-demand revalidation
```typescript
// app/api/revalidate/route.ts
import { revalidatePath, revalidateTag } from 'next/cache';

export async function POST(request: Request) {
  const { secret, path, tag } = await request.json();

  if (secret !== process.env.REVALIDATE_SECRET) {
    return NextResponse.json({ error: 'Invalid secret' }, { status: 401 });
  }

  if (path) revalidatePath(path);
  if (tag) revalidateTag(tag);

  return NextResponse.json({ revalidated: true });
}

// Use khi update product
await fetch(`${process.env.APP_URL}/api/revalidate`, {
  method: 'POST',
  body: JSON.stringify({
    secret: process.env.REVALIDATE_SECRET,
    path: `/san-pham/${product.slug}`,
  }),
});
```

### Redis Cache
```typescript
// lib/cache.ts
import { Redis } from '@upstash/redis';

const redis = Redis.fromEnv();

export async function cached<T>(
  key: string,
  fn: () => Promise<T>,
  ttl: number = 300
): Promise<T> {
  const cached = await redis.get<T>(key);
  if (cached) return cached;

  const value = await fn();
  await redis.set(key, value, { ex: ttl });
  return value;
}

// Usage
const products = await cached(
  `products:featured`,
  () => prisma.product.findMany({ where: { isFeatured: true } }),
  600 // 10 min
);
```

## 🌍 Vietnamese Hosting Considerations

### CDN cho VN
- **Cloudflare** - Free, có PoP tại VN
- **BunnyCDN** - Rẻ, hiệu năng tốt cho VN
- **Vercel Edge** - Tốt nhưng PoP gần nhất ở Singapore

### Performance tips cho VN
- **DNS:** Dùng Cloudflare DNS hoặc Google DNS
- **Image optimization:** Cloudinary có CDN ASEAN
- **Font:** Tự host hoặc Cloudflare Fonts thay vì Google Fonts (block ở 1 số ISP)
- **External JS:** Tránh GA, Tag Manager block render

### Domain & SSL
- **Domain:** `.com.vn` cho tin cậy local, `.vn` cho B2B
- **SSL:** Let's Encrypt free, hoặc Cloudflare SSL
- **HTTPS redirect:** Bắt buộc HTTPS

### Compliance
- **Nghị định 13/2023:** Personal Data Protection
  - Privacy policy bắt buộc
  - User consent cho data collection
  - Right to delete data
- **Thông tư về website TMĐT:**
  - Đăng ký với Bộ Công Thương
  - Logo "Đã đăng ký" hiển thị

## 🚨 Disaster Recovery

### Backup Strategy
```bash
# Daily automated DB backup
0 2 * * * pg_dump $DATABASE_URL | gzip > /backups/db-$(date +\%Y\%m\%d).sql.gz

# Retention: 7 daily + 4 weekly + 12 monthly
# Storage: AWS S3 / Cloudflare R2 (cheap)

# Backup file storage (Cloudinary/S3)
# - Cloudinary: tự backup
# - S3: enable versioning + cross-region replication
```

### Incident Response Playbook

**Down/Slow site:**
1. Check Vercel status page
2. Check `/api/health`
3. Check Sentry for errors
4. Check DB connection count
5. Check Redis status
6. Rollback nếu mới deploy

**Payment errors:**
1. Check webhook logs
2. Check payment gateway status
3. Notify support team
4. Manual reconciliation nếu cần

**Database issues:**
1. Check connection pool
2. Check slow queries
3. Read replicas nếu có
4. Restore from backup nếu corrupted

## ✅ Pre-Launch Checklist

### Infrastructure
- [ ] Domain configured với DNS
- [ ] SSL certificate (HTTPS)
- [ ] CDN configured (Cloudflare)
- [ ] Database production-grade (with backup)
- [ ] Redis cache setup
- [ ] File storage (Cloudinary) setup
- [ ] Email service tested

### Security
- [ ] All env vars in production set
- [ ] No secrets in code/Git
- [ ] HTTPS enforced
- [ ] Security headers configured
- [ ] Rate limiting tested
- [ ] WAF rules (Cloudflare)

### Performance
- [ ] Lighthouse > 90 on all pages
- [ ] Core Web Vitals passing
- [ ] Images optimized
- [ ] Caching configured
- [ ] CDN warm

### Monitoring
- [ ] Sentry receiving errors
- [ ] Uptime monitoring active
- [ ] Slack alerts configured
- [ ] Logs aggregating

### Business
- [ ] Privacy policy page
- [ ] Terms of service
- [ ] Return policy
- [ ] Bộ Công Thương registration
- [ ] Customer support channels live
- [ ] Test orders processed end-to-end

### Launch Day
- [ ] Final DB backup taken
- [ ] Team on standby
- [ ] Monitoring dashboards open
- [ ] Customer support ready
- [ ] Rollback plan ready
