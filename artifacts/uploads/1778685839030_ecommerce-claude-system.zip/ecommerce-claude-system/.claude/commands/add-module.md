---
description: Thêm một module mới vào hệ thống e-commerce (vd catalog, cart, checkout...)
argument-hint: [tên module]
---

# Add Module: $ARGUMENTS

Implement đầy đủ một module mới của hệ thống e-commerce theo chuẩn dự án.

## Quy trình implement

### 1. Phân tích yêu cầu
- Đọc skill `ecommerce-architecture` để hiểu module này thuộc đâu trong tổng thể
- Xác định ranh giới module (input/output, dependencies)
- Liệt kê các features cần làm

### 2. Database Layer (đọc skill `database-schema`)
- Thêm/cập nhật Prisma models
- Thêm indexes cho queries thường dùng
- Tạo migration: `pnpm prisma migrate dev --name add_$ARGUMENTS_module`
- Seed data nếu cần

### 3. Business Logic (lib/services/)
- Tạo service file: `lib/services/$ARGUMENTS.ts`
- Logic thuần, không phụ thuộc framework
- Có unit tests đi kèm

### 4. API Layer (đọc skill `api-design`)
- Tạo route handlers trong `app/api/$ARGUMENTS/`
- Zod schemas cho input validation
- Auth/authorization với `withAuth` middleware nếu cần
- Rate limiting cho endpoints public
- Integration tests

### 5. UI Layer (đọc skill `ui-design`)
- Tạo components trong `components/shop/$ARGUMENTS/` hoặc `components/admin/$ARGUMENTS/`
- Sử dụng design tokens từ `tailwind.config.ts`
- Mobile-first responsive
- Loading, error, empty states

### 6. Pages (App Router)
- Tạo pages trong `app/(shop)/...` hoặc `app/(admin)/admin/...`
- Server Components mặc định
- 'use client' chỉ khi cần interactivity
- Metadata API cho SEO (đọc skill `seo-optimization`)

### 7. Security (đọc skill `security`)
- Authorization checks
- Input validation
- IDOR prevention
- Rate limiting

### 8. Testing (đọc skill `testing`)
- Unit tests cho business logic
- Integration tests cho API
- E2E tests cho critical flow

### 9. Documentation
- Cập nhật `CLAUDE.md` nếu có conventions mới
- Cập nhật API docs trong `docs/api.md`

### 10. Git (đọc skill `git-workflow`)
- Branch: `feature/$ARGUMENTS-module`
- Commits theo Conventional Commits
- PR description chi tiết

## Checklist trước khi xong

- [ ] Database schema + migration
- [ ] Business logic service + unit tests pass
- [ ] API routes + integration tests pass
- [ ] UI components responsive (mobile/tablet/desktop)
- [ ] Authorization đúng cho mọi protected route
- [ ] Loading/error/empty states đầy đủ
- [ ] SEO metadata cho public pages
- [ ] Vietnamese formatting (VND, dates)
- [ ] Lint pass, type-check pass
- [ ] Đã test thủ công trên local

## Lưu ý

Module ưu tiên implement theo thứ tự:
1. **catalog** (products, categories) - foundation
2. **user** (auth, profile, addresses)
3. **cart**
4. **checkout** + **order**
5. **payment** (đọc skill `payment-vn`)
6. **shipping**
7. **review**
8. **promotion** (vouchers)
9. **admin**
