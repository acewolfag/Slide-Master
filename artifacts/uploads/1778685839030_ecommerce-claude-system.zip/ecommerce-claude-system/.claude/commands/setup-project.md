---
description: Khởi tạo dự án Next.js e-commerce với cấu trúc đúng theo CLAUDE.md
---

# Setup Project

Khởi tạo dự án Next.js 14 e-commerce hoàn chỉnh với cấu trúc folder, dependencies và config theo chuẩn dự án.

## Steps

1. **Khởi tạo Next.js project**
   ```bash
   pnpm create next-app@latest . --typescript --tailwind --app --src-dir=false --import-alias="@/*" --eslint
   ```

2. **Cài dependencies cốt lõi**
   ```bash
   pnpm add next-auth@beta @auth/prisma-adapter
   pnpm add @prisma/client zod
   pnpm add zustand @tanstack/react-query
   pnpm add bcryptjs
   pnpm add @upstash/redis @upstash/ratelimit
   pnpm add resend
   pnpm add date-fns
   pnpm add lucide-react clsx tailwind-merge class-variance-authority
   ```

3. **Cài dev dependencies**
   ```bash
   pnpm add -D prisma
   pnpm add -D @types/bcryptjs
   pnpm add -D vitest @vitejs/plugin-react jsdom @testing-library/react @testing-library/jest-dom
   pnpm add -D @playwright/test
   pnpm add -D husky lint-staged @commitlint/cli @commitlint/config-conventional
   pnpm add -D prettier prettier-plugin-tailwindcss
   ```

4. **Tạo folder structure** theo `CLAUDE.md`:
   - `app/(shop)/` — public routes
   - `app/(auth)/` — auth routes
   - `app/(admin)/admin/` — admin panel
   - `app/api/` — API routes
   - `components/ui/`, `components/shop/`, `components/admin/`
   - `lib/` — utilities, db, auth
   - `hooks/`, `stores/`, `types/`
   - `prisma/` — schema và migrations
   - `tests/unit/`, `tests/e2e/`

5. **Init Prisma và copy schema** từ skill `database-schema`

6. **Setup Husky** cho pre-commit hooks

7. **Tạo `.env.local`** từ `.env.example`

8. **Setup shadcn/ui**
   ```bash
   pnpm dlx shadcn@latest init
   ```

## Notes

- Đọc skill `database-schema` để lấy Prisma schema đầy đủ
- Đọc skill `ui-design` để setup design tokens trong `tailwind.config.ts`
- Đọc skill `security` để config security headers trong `next.config.js`
- Đọc skill `git-workflow` để setup commitlint và husky

Sau khi setup xong, hỏi user muốn implement module nào đầu tiên (catalog, auth, cart, checkout...)
