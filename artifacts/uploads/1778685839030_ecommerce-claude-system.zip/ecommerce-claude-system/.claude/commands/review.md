---
description: Review code thay đổi gần nhất theo checklist của dự án
---

# Code Review

Review code thay đổi gần nhất một cách chi tiết theo checklist của dự án.

## Quy trình

### 1. Xem diff hiện tại
```bash
git diff HEAD
git diff --staged
```

### 2. Review theo các tiêu chí (đọc skill `git-workflow` mục 4)

#### ✅ Functionality
- Code có làm đúng những gì description nói không?
- Edge cases đã xử lý chưa? (null, empty array, max values)
- Error handling đầy đủ chưa?
- Hardcoded values nào nên đưa vào env/constants không?

#### 🔒 Security (đọc skill `security`)
- Input validation với Zod ở mọi entry point?
- Có SQL injection risk không? (kiểm tra raw queries)
- Có XSS risk không? (user content được escape chưa?)
- Authorization check ở mọi protected route?
- Có log PII không? (password, token, card number)
- Secrets có bị hardcode không?

#### ⚡ Performance
- N+1 query? (kiểm tra Prisma `include`/`select`)
- Pagination cho list endpoints?
- Cache headers cho static content?
- Image optimization với next/image?
- Bundle size có tăng đột biến không?

#### 📐 Code Quality
- Naming có rõ ràng, self-explanatory?
- Functions ngắn (< 50 dòng), single responsibility?
- Có duplicate code không?
- TypeScript có dùng `any` không?
- Comments có giải thích "why" không phải "what"?

#### 🧪 Testing (đọc skill `testing`)
- Unit tests cho business logic?
- Integration tests cho API endpoints?
- E2E test cho critical flow?
- Tests có ý nghĩa không, hay chỉ để cover lines?

#### 🎨 UI/UX (nếu có UI changes)
- Responsive trên mobile (375px), tablet (768px), desktop (1280px)?
- Loading states?
- Error states?
- Empty states?
- Accessibility (keyboard nav, ARIA, contrast)?
- Vietnamese text (font, dấu tiếng Việt) hiển thị đúng?

#### 💾 Database (nếu có migration)
- Migration backwards-compatible?
- Có rollback plan?
- Indexes cho queries thường dùng?
- Có lock table lâu trên prod không?

### 3. Format output

Cho mỗi issue tìm thấy, dùng format:

```
🔴 BLOCKER: [security/correctness issues - PHẢI fix]
🟠 ISSUE: [bugs hoặc design issues - nên fix]
🟡 SUGGESTION: [improvements - không bắt buộc]
🟢 NIT: [nhỏ như typo, formatting]
```

Mỗi issue gồm:
- File và dòng cụ thể
- Mô tả vấn đề
- Đề xuất cách fix (kèm code nếu cần)

### 4. Tổng kết

Cuối review:
- ✅ Số lượng issues theo từng level
- 📊 Coverage assessment
- 🎯 Recommendation: APPROVE / REQUEST CHANGES / COMMENT

## Mức độ review

- **Skim review**: chỉ nhìn structure, naming, obvious issues
- **Standard review** (mặc định): đầy đủ checklist trên
- **Deep review**: xem cả test coverage, performance benchmark, security audit
