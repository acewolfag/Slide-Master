# CLAUDE.md - Dự án Website Bán Hàng

> File này được Claude Code tự động đọc khi làm việc trong dự án. Đây là "bộ não" định hướng cho mọi tác vụ.

## 🎯 Tổng quan dự án

**Tên dự án:** [Tên dự án của bạn]
**Loại:** Website thương mại điện tử (E-commerce)
**Ngôn ngữ chính:** Tiếng Việt (UI), tiếng Anh (code/comments)
**Đối tượng:** Khách hàng Việt Nam

## 🏗️ Tech Stack

### Frontend
- **Framework:** Next.js 14+ (App Router)
- **Language:** TypeScript (strict mode)
- **Styling:** Tailwind CSS + shadcn/ui
- **State:** Zustand (client) + TanStack Query (server)
- **Forms:** React Hook Form + Zod validation

### Backend
- **API:** Next.js Route Handlers / tRPC
- **Database:** PostgreSQL + Prisma ORM
- **Auth:** NextAuth.js (Auth.js v5)
- **File Storage:** Cloudinary / AWS S3
- **Cache:** Redis (Upstash)

### Payment & Integration
- **Thanh toán VN:** VNPay, MoMo, ZaloPay
- **Vận chuyển:** GHN, GHTK API
- **Email:** Resend / SendGrid
- **Analytics:** Google Analytics 4 + Vercel Analytics

### DevOps
- **Hosting:** Vercel (frontend) + Railway/Supabase (DB)
- **CI/CD:** GitHub Actions
- **Monitoring:** Sentry

## 📁 Cấu trúc thư mục

```
.
├── .claude/
│   ├── skills/           # Các skill chuyên biệt
│   └── commands/         # Custom slash commands
├── src/
│   ├── app/              # Next.js App Router
│   │   ├── (shop)/       # Route group cho khách hàng
│   │   ├── (admin)/      # Route group cho admin
│   │   ├── api/          # API routes
│   │   └── auth/         # Authentication pages
│   ├── components/
│   │   ├── ui/           # shadcn components
│   │   ├── shop/         # Components cho shop
│   │   ├── admin/        # Components cho admin
│   │   └── shared/       # Components dùng chung
│   ├── lib/
│   │   ├── db.ts         # Prisma client
│   │   ├── auth.ts       # Auth config
│   │   ├── payment/      # Payment gateways
│   │   └── utils.ts      # Helper functions
│   ├── hooks/            # Custom React hooks
│   ├── types/            # TypeScript types
│   └── styles/           # Global styles
├── prisma/
│   ├── schema.prisma     # Database schema
│   ├── migrations/       # DB migrations
│   └── seed.ts           # Seed data
├── public/               # Static assets
├── tests/                # Test files
└── docs/                 # Documentation
```

## ⚡ Quy tắc làm việc bắt buộc

### 1. Nguyên tắc cốt lõi
- **LUÔN đọc skill liên quan** trong `.claude/skills/` trước khi code
- **KHÔNG tạo file mới** nếu có thể edit file hiện có
- **KHÔNG tạo documentation** trừ khi được yêu cầu rõ ràng
- **LUÔN verify** schema database trước khi viết query
- **LUÔN type-safe** - không dùng `any`, dùng `unknown` nếu cần

### 2. Code Style
- **Naming:**
  - Components: `PascalCase` (VD: `ProductCard.tsx`)
  - Functions/variables: `camelCase`
  - Constants: `UPPER_SNAKE_CASE`
  - Files API: `kebab-case` (VD: `create-order.ts`)
- **Imports:** Absolute paths với `@/` alias
- **Comments:** Tiếng Anh, JSDoc cho public APIs

### 3. Git Workflow
- **Branch naming:** `feature/`, `fix/`, `chore/`, `refactor/`
- **Commit:** Conventional Commits (feat:, fix:, docs:, etc.)
- **PR:** Mô tả rõ "What" và "Why", screenshots cho UI changes

### 4. Bảo mật (CRITICAL)
- **KHÔNG BAO GIỜ** commit `.env`, API keys, secrets
- **LUÔN validate** input ở cả client và server
- **LUÔN sanitize** user input để tránh XSS
- **LUÔN dùng** parameterized queries (Prisma đã handle)
- **LUÔN check** quyền (authorization) ở mỗi API endpoint
- **Rate limiting** cho auth endpoints và checkout

### 5. Performance
- **Images:** Next.js `<Image>` với `priority` cho LCP
- **Fonts:** `next/font` để tránh layout shift
- **Code splitting:** Dynamic imports cho heavy components
- **Database:** Index các trường thường query, dùng `select` để giảm payload
- **Caching:** ISR cho product pages, on-demand revalidation khi update

## 🎨 UI/UX Guidelines

- **Design system:** Theo `.claude/skills/ui-design/SKILL.md`
- **Mobile-first:** 80% user Việt Nam dùng mobile
- **Loading states:** Skeleton screens, không dùng spinner đơn thuần
- **Error handling:** Toast notifications + inline errors
- **Accessibility:** WCAG 2.1 AA, keyboard navigation, ARIA labels
- **Dark mode:** Hỗ trợ từ đầu (Tailwind `dark:` variants)

## 💰 Business Logic quan trọng

### Sản phẩm (Products)
- Hỗ trợ biến thể (variants): màu sắc, size, dung lượng
- Tracking inventory real-time
- SEO-friendly URLs: `/san-pham/[slug]`
- Hình ảnh: WebP/AVIF, multiple sizes

### Giỏ hàng (Cart)
- Persist cho guest users (localStorage) và logged-in users (DB)
- Merge cart khi user đăng nhập
- Validate stock trước khi checkout
- Tính giá real-time (khuyến mãi, voucher, ship)

### Đơn hàng (Orders)
- States: `pending` → `confirmed` → `processing` → `shipping` → `delivered` / `cancelled`
- Idempotency keys cho payment callbacks
- Email notification cho mỗi state change
- Hỗ trợ COD và thanh toán online

### Thanh toán
- Theo `.claude/skills/payment-vn/SKILL.md`
- LUÔN verify callback signature
- Log mọi transaction để audit
- Handle timeout và edge cases

## 🧪 Testing Strategy

- **Unit tests:** Vitest cho logic và utils
- **Integration:** Testing Library cho components
- **E2E:** Playwright cho critical flows (checkout, auth)
- **Coverage target:** 70%+ cho business logic

## 📊 Database Conventions

- Mọi bảng có: `id` (cuid), `createdAt`, `updatedAt`
- Soft delete với `deletedAt` cho dữ liệu quan trọng
- Foreign keys với `onDelete` rule rõ ràng
- Indexes cho: foreign keys, search fields, sort fields

## 🚀 Skills có sẵn

Đọc các skill này khi cần:

| Skill | Khi nào dùng |
|-------|-------------|
| `ecommerce-architecture` | Thiết kế hệ thống, business flow |
| `ui-design` | Thiết kế component, layout |
| `database-schema` | Thiết kế DB, migration |
| `api-design` | Tạo API endpoints, REST/tRPC |
| `payment-vn` | Tích hợp VNPay, MoMo, ZaloPay |
| `seo-optimization` | Meta tags, sitemap, structured data |
| `security` | Auth, validation, sanitization |
| `testing` | Viết test, mocking |
| `deployment` | Deploy, CI/CD, monitoring |
| `git-workflow` | Commit, branch, PR |

## ⚠️ Cảnh báo quan trọng

- **KHÔNG** dùng `dangerouslySetInnerHTML` trừ khi đã sanitize với DOMPurify
- **KHÔNG** expose Prisma errors trực tiếp cho client
- **KHÔNG** lưu password plain text - LUÔN bcrypt với salt rounds >= 10
- **KHÔNG** trust client-side prices - LUÔN tính lại ở server
- **KHÔNG** dùng `localStorage` cho sensitive data (token, payment info)
- **KHÔNG** skip TypeScript errors với `@ts-ignore` - dùng `@ts-expect-error` với comment

## 📝 Workflow đề xuất khi nhận task mới

1. **Đọc** task requirements kỹ
2. **Identify** skills cần dùng → đọc skill files
3. **Plan** - liệt kê files cần tạo/sửa
4. **Verify** với database schema và existing code
5. **Implement** - code + types + validation
6. **Test** - viết test cho logic phức tạp
7. **Review** - check security, performance, accessibility
8. **Commit** - theo conventional commits

## 🔗 Tài liệu tham khảo

- `docs/architecture.md` - Kiến trúc tổng thể
- `docs/api.md` - API documentation
- `docs/database.md` - Schema documentation
- `docs/deployment.md` - Hướng dẫn deploy

---

**Phiên bản:** 1.0.0
**Cập nhật lần cuối:** 2026-05-02
